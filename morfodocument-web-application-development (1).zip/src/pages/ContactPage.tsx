import { useState } from "react";
import { useAppState } from "../store";
import { translations } from "../i18n";
import { toast } from "../components/Toast";
import { Mail, Send, Check, MessageSquare, User, AtSign, Type } from "lucide-react";

// Using Web3Forms - free form-to-email service for static sites
// The access_key here is a demo placeholder. In production, get your own from https://web3forms.com
const WEB3FORMS_KEY = "b3a3c3e3-1234-5678-9abc-def012345678"; // Replace with your real key

export function ContactPage() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  // Honeypot
  const [botcheck, setBotcheck] = useState("");

  const isValidEmail = (e: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

  const send = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email || !subject || !message) {
      toast.show("error", t.fieldRequired);
      return;
    }
    if (!isValidEmail(email)) {
      toast.show("error", t.invalidEmail);
      return;
    }
    if (message.length < 10) {
      toast.show("error", t.minChars);
      return;
    }
    if (botcheck) return; // Honeypot

    setLoading(true);
    try {
      const res = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify({
          access_key: WEB3FORMS_KEY,
          name: name || "Anonymous",
          email,
          subject: `[MorfoDocument] ${subject}`,
          message,
          from_name: "MorfoDocument Contact Form",
          to: "mahdirezaiean01@gmail.com",
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSent(true);
        toast.show("success", t.sentMsg);
        setName(""); setEmail(""); setSubject(""); setMessage("");
      } else {
        // Fallback: use mailto link
        window.location.href = `mailto:mahdirezaiean01@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(`From: ${name} (${email})\n\n${message}`)}`;
        setSent(true);
        toast.show("success", t.sentMsg);
      }
    } catch (err) {
      // Fallback: use mailto
      window.location.href = `mailto:mahdirezaiean01@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(`From: ${name} (${email})\n\n${message}`)}`;
      setSent(true);
      toast.show("success", t.sentMsg);
    }
    setLoading(false);
  };

  if (sent) {
    return (
      <div className="max-w-2xl mx-auto py-12">
        <div className="glass-strong rounded-3xl p-8 sm:p-12 text-center space-y-4 animate-fade-in">
          <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center shadow-lg shadow-emerald-300 dark:shadow-emerald-900 animate-bounce">
            <Check className="h-10 w-10 text-white" strokeWidth={3} />
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold">{t.sent} ✓</h2>
          <p className="text-slate-600 dark:text-slate-300">{t.sentMsg}</p>
          <button onClick={() => setSent(false)} className="btn-secondary mt-4">
            {t.back}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6 py-4 sm:py-8">
      <div className="text-center space-y-3">
        <div className="inline-flex w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-500 to-pink-500 items-center justify-center shadow-lg">
          <MessageSquare className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-black bg-gradient-to-r from-violet-600 to-pink-600 bg-clip-text text-transparent">
          {t.contactTitle}
        </h1>
        <p className="text-slate-600 dark:text-slate-300 max-w-md mx-auto">
          {t.contactSub}
        </p>
      </div>

      <form onSubmit={send} className="glass-strong rounded-3xl p-6 sm:p-8 space-y-4">
        {/* Honeypot */}
        <input type="text" name="botcheck" value={botcheck} onChange={(e) => setBotcheck(e.target.value)} className="hidden" style={{ display: "none" }} tabIndex={-1} autoComplete="off" />

        <div>
          <label className="text-sm font-medium flex items-center gap-2 mb-1.5">
            <User className="h-3.5 w-3.5" />
            {t.yourName} <span className="text-xs text-slate-400">{t.optional}</span>
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t.yourName}
            className="input"
            maxLength={80}
          />
        </div>

        <div>
          <label className="text-sm font-medium flex items-center gap-2 mb-1.5">
            <AtSign className="h-3.5 w-3.5" />
            {t.yourEmail} *
          </label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            className="input"
            required
          />
        </div>

        <div>
          <label className="text-sm font-medium flex items-center gap-2 mb-1.5">
            <Type className="h-3.5 w-3.5" />
            {t.messageSubject} *
          </label>
          <input
            type="text"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="..."
            className="input"
            maxLength={150}
            required
          />
        </div>

        <div>
          <label className="text-sm font-medium flex items-center gap-2 mb-1.5">
            <Mail className="h-3.5 w-3.5" />
            {t.messageBody} *
          </label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="..."
            className="input min-h-[150px] resize-y"
            required
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="btn-primary w-full flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              {t.sending}
            </>
          ) : (
            <>
              <Send className="h-4 w-4" />
              {t.send}
            </>
          )}
        </button>

        <p className="text-xs text-center text-slate-500 dark:text-slate-400">
          پیام شما مستقیماً به <span className="font-mono">mahdirezaiean01@gmail.com</span> ارسال می‌شود
        </p>
      </form>
    </div>
  );
}
