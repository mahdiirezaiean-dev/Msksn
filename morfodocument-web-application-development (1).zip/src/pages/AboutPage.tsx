import { useAppState } from "../store";
import { translations } from "../i18n";
import { Mail, Heart, Sparkles, Shield, Wifi, Lock, Zap, Globe, FileText, Image as ImageIcon, ScanLine, Edit3 } from "lucide-react";

// Custom Instagram icon
const Instagram = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
  </svg>
);

export function AboutPage() {
  const { locale } = useAppState();
  const t = translations[locale];

  return (
    <div className="max-w-4xl mx-auto space-y-8 sm:space-y-12 py-4 sm:py-8">
      {/* Hero card */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-br from-violet-500/20 via-pink-500/20 to-fuchsia-500/20 blur-3xl rounded-3xl" />
        <div className="relative glass-strong rounded-3xl p-6 sm:p-10 text-center space-y-4 sm:space-y-6">
          {/* Avatar / Monogram */}
          <div className="relative inline-block">
            <div className="absolute inset-0 bg-gradient-to-br from-violet-500 to-pink-500 blur-2xl opacity-50 animate-pulse" />
            <div className="relative w-24 h-24 sm:w-32 sm:h-32 mx-auto rounded-3xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-pink-500 flex items-center justify-center shadow-2xl shadow-violet-300 dark:shadow-violet-900">
              <span className="text-white font-black text-5xl sm:text-7xl">M</span>
            </div>
          </div>

          <div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-black bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-600 bg-clip-text text-transparent">
              {t.aboutTitle}
            </h1>
            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 mt-3 max-w-2xl mx-auto">
              {t.aboutLead}
            </p>
          </div>

          {/* Trust badges */}
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3">
            {[
              { icon: Lock, label: t.private, color: "from-violet-500 to-purple-500" },
              { icon: Wifi, label: t.offline, color: "from-pink-500 to-rose-500" },
              { icon: Shield, label: t.secure, color: "from-indigo-500 to-violet-500" },
              { icon: Heart, label: t.free, color: "from-fuchsia-500 to-pink-500" },
            ].map((b, i) => (
              <div key={i} className="glass rounded-full px-3 sm:px-4 py-1.5 sm:py-2 flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm">
                <b.icon className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                <span className="font-medium">{b.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Story */}
      <div className="grid md:grid-cols-3 gap-4 sm:gap-6">
        {[
          { icon: Shield, title: t.private, body: t.aboutP1 },
          { icon: Zap, title: t.featureAdvanced, body: t.aboutP2 },
          { icon: Heart, title: t.free, body: t.aboutP3 },
        ].map((card, i) => (
          <div key={i} className="glass-strong rounded-2xl p-5 sm:p-6 space-y-3 hover:scale-105 transition-transform">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center">
              <card.icon className="h-6 w-6 text-white" />
            </div>
            <h3 className="font-bold text-lg">{card.title}</h3>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{card.body}</p>
          </div>
        ))}
      </div>

      {/* Features showcase */}
      <div className="glass-strong rounded-3xl p-6 sm:p-8 space-y-4">
        <h3 className="font-bold text-lg flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-violet-500" />
          {t.featureAdvanced}
        </h3>
        <div className="grid sm:grid-cols-2 gap-3 text-sm">
          {[
            { icon: FileText, text: "PDF Reader, Merge, Split, Watermark" },
            { icon: ScanLine, text: "OCR فارسی و انگلیسی + اسکن دوربین" },
            { icon: ImageIcon, text: "تبدیل PDF به عکس و بالعکس" },
            { icon: Edit3, text: "ویرایش متادیتا، شماره صفحه، امضا" },
            { icon: Lock, text: "رمز عبور، Redaction، مقایسه PDF" },
            { icon: Globe, text: "۱۰ زبان زنده دنیا با پشتیبانی کامل فارسی" },
          ].map((f, i) => (
            <div key={i} className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-violet-50 dark:hover:bg-violet-900/20">
              <f.icon className="h-4 w-4 text-violet-500 flex-shrink-0" />
              <span>{f.text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Creator card */}
      <div className="glass-strong rounded-3xl p-6 sm:p-10">
        <p className="text-xs uppercase tracking-widest text-slate-500 text-center mb-4">{t.madeBy}</p>
        <div className="flex flex-col sm:flex-row items-center gap-6">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-violet-500 to-pink-500 blur-xl opacity-50" />
            <div className="relative w-24 h-24 sm:w-32 sm:h-32 rounded-full bg-gradient-to-br from-violet-500 via-fuchsia-500 to-pink-500 flex items-center justify-center shadow-2xl">
              <span className="text-white font-black text-4xl sm:text-5xl">M</span>
            </div>
          </div>
          <div className="flex-1 text-center sm:text-start">
            <h2 className="text-2xl sm:text-3xl font-black">محمد مهدی رضائیان</h2>
            <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 mb-1">Mohammad Mahdi Rezaeian</p>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mb-4">
              توسعه‌دهنده و طراح — سازنده MorfoDocument
            </p>
            <div className="flex flex-wrap items-center gap-2 sm:gap-3 justify-center sm:justify-start">
              <a
                href="https://instagram.com/mahdiirezaiean"
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-2 glass rounded-full px-4 py-2 hover:bg-gradient-to-r hover:from-pink-500 hover:to-rose-500 hover:text-white transition-all"
              >
                <Instagram className="h-4 w-4 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium">@mahdiirezaiean</span>
              </a>
              <a
                href="mailto:mahdirezaiean01@gmail.com"
                className="group flex items-center gap-2 glass rounded-full px-4 py-2 hover:bg-gradient-to-r hover:from-violet-500 hover:to-indigo-500 hover:text-white transition-all"
              >
                <Mail className="h-4 w-4 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium break-all">mahdirezaiean01@gmail.com</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="text-center text-xs text-slate-500 dark:text-slate-400">
        {t.copyright}
      </div>
    </div>
  );
}
