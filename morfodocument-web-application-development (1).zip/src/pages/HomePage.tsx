import { useState, useMemo } from "react";
import { useAppState } from "../store";
import { translations } from "../i18n";
import { Search, Sparkles, FileText, ScanLine, Edit, Lock, Image as ImageIcon, FileSearch, FileType, PenTool, Layers, Combine, Type, Minimize2, Droplet, Eye, Hash, Shield, FileSpreadsheet, QrCode, History, ArrowLeft, ShieldCheck, Wifi, Lock as LockIcon, Heart } from "lucide-react";

interface Tool {
  id: string;
  name: string;
  desc: string;
  category: "convert" | "edit" | "security" | "scan";
  icon: any;
  gradient: string;
  badge?: "new" | "popular";
}

const TOOLS: Tool[] = [
  { id: "pdf-reader", name: "toolPdfReader", desc: "toolPdfReaderDesc", category: "edit", icon: FileText, gradient: "from-blue-500 to-cyan-500" },
  { id: "scan", name: "toolScan", desc: "toolScanDesc", category: "scan", icon: ScanLine, gradient: "from-violet-500 to-purple-500", badge: "popular" },
  { id: "pdf-to-image", name: "toolPdfToImage", desc: "toolPdfToImageDesc", category: "convert", icon: ImageIcon, gradient: "from-pink-500 to-rose-500" },
  { id: "image-to-pdf", name: "toolImageToPdf", desc: "toolImageToPdfDesc", category: "convert", icon: FileType, gradient: "from-orange-500 to-amber-500" },
  { id: "split", name: "toolSplit", desc: "toolSplitDesc", category: "edit", icon: Layers, gradient: "from-fuchsia-500 to-pink-500" },
  { id: "merge", name: "toolMerge", desc: "toolMergeDesc", category: "edit", icon: Combine, gradient: "from-indigo-500 to-violet-500" },
  { id: "text-to-pdf", name: "toolTextToPdf", desc: "toolTextToPdfDesc", category: "convert", icon: Type, gradient: "from-emerald-500 to-teal-500" },
  { id: "compress", name: "toolCompress", desc: "toolCompressDesc", category: "edit", icon: Minimize2, gradient: "from-cyan-500 to-blue-500" },
  { id: "watermark", name: "toolWatermark", desc: "toolWatermarkDesc", category: "edit", icon: Droplet, gradient: "from-purple-500 to-fuchsia-500" },
  { id: "ocr", name: "toolOcr", desc: "toolOcrDesc", category: "scan", icon: FileSearch, gradient: "from-rose-500 to-pink-500", badge: "popular" },
  { id: "sign", name: "toolSign", desc: "toolSignDesc", category: "security", icon: PenTool, gradient: "from-violet-500 to-indigo-500" },
  { id: "lock", name: "toolLock", desc: "toolLockDesc", category: "security", icon: Lock, gradient: "from-slate-500 to-zinc-600" },
  { id: "metadata", name: "toolMetadata", desc: "toolMetadataDesc", category: "edit", icon: Edit, gradient: "from-amber-500 to-orange-500" },
  { id: "page-number", name: "toolPageNum", desc: "toolPageNumDesc", category: "edit", icon: Hash, gradient: "from-teal-500 to-emerald-500" },
  { id: "compare", name: "toolCompare", desc: "toolCompareDesc", category: "edit", icon: Eye, gradient: "from-cyan-500 to-sky-500", badge: "new" },
  { id: "form", name: "toolForm", desc: "toolFormDesc", category: "edit", icon: FileSpreadsheet, gradient: "from-green-500 to-emerald-500", badge: "new" },
  { id: "qr", name: "toolQr", desc: "toolQrDesc", category: "scan", icon: QrCode, gradient: "from-pink-500 to-fuchsia-500" },
  { id: "history", name: "toolHistory", desc: "toolHistoryDesc", category: "edit", icon: History, gradient: "from-gray-500 to-slate-500" },
];

interface Props {
  onSelect: (id: string) => void;
}

export function HomePage({ onSelect }: Props) {
  const { locale } = useAppState();
  const t = translations[locale];
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string>("all");

  const filtered = useMemo(() => {
    return TOOLS.filter(tool => {
      const name = (t[tool.name as keyof typeof t] || tool.name).toLowerCase();
      const desc = (t[tool.desc as keyof typeof t] || tool.desc).toLowerCase();
      const matchSearch = !search || name.includes(search.toLowerCase()) || desc.includes(search.toLowerCase());
      const matchCat = category === "all" || tool.category === category;
      return matchSearch && matchCat;
    });
  }, [search, category, t]);

  return (
    <div className="space-y-8 sm:space-y-12">
      {/* Hero */}
      <section className="relative pt-4 sm:pt-8">
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute top-0 start-1/4 w-72 h-72 bg-violet-400/20 rounded-full blur-3xl" />
          <div className="absolute top-20 end-1/4 w-72 h-72 bg-pink-400/20 rounded-full blur-3xl" />
        </div>
        <div className="text-center max-w-3xl mx-auto space-y-4 sm:space-y-6">
          <div className="inline-flex items-center gap-2 glass rounded-full px-3 sm:px-4 py-1.5 text-xs sm:text-sm">
            <Sparkles className="h-3.5 w-3.5 text-violet-500" />
            <span className="font-medium">{t.tagline}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl md:text-6xl font-black leading-tight">
            <span className="bg-gradient-to-r from-violet-600 via-fuchsia-600 to-pink-600 bg-clip-text text-transparent">
              {t.heroTitle}
            </span>
          </h1>
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
            {t.heroSubtitle}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 pt-2">
            {[
              { icon: ShieldCheck, label: t.trustBadge1, color: "from-violet-500 to-indigo-500" },
              { icon: Wifi, label: t.trustBadge2, color: "from-pink-500 to-rose-500" },
              { icon: LockIcon, label: t.trustBadge3, color: "from-fuchsia-500 to-purple-500" },
              { icon: Heart, label: t.free, color: "from-amber-500 to-orange-500" },
            ].map((b, i) => (
              <div key={i} className="glass rounded-full px-3 sm:px-4 py-1.5 sm:py-2 flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm shadow-sm">
                <div className={`w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-gradient-to-br ${b.color} flex items-center justify-center`}>
                  <b.icon className="h-2.5 w-2.5 sm:h-3 sm:w-3 text-white" />
                </div>
                <span className="font-medium">{b.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Search & Filter */}
      <section className="space-y-4">
        <div className="relative max-w-xl mx-auto">
          <Search className="absolute top-1/2 -translate-y-1/2 start-4 h-5 w-5 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.search_placeholder}
            className="input !ps-12 !py-3.5 !text-base shadow-lg"
          />
        </div>
        <div className="flex flex-wrap items-center justify-center gap-2">
          {[
            { id: "all", label: t.appName, icon: Sparkles },
            { id: "convert", label: t.categoryConvert, icon: ImageIcon },
            { id: "edit", label: t.categoryEdit, icon: Edit },
            { id: "security", label: t.categorySecurity, icon: Shield },
            { id: "scan", label: t.categoryScan, icon: ScanLine },
          ].map(c => (
            <button
              key={c.id}
              onClick={() => setCategory(c.id)}
              className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-xs sm:text-sm font-medium transition-all flex items-center gap-1.5 ${
                category === c.id
                  ? "bg-gradient-to-r from-violet-500 to-pink-500 text-white shadow-lg"
                  : "glass hover:scale-105"
              }`}
            >
              <c.icon className="h-3.5 w-3.5" />
              {c.label}
            </button>
          ))}
        </div>
      </section>

      {/* Tools Grid */}
      <section>
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-500">
            <Search className="h-12 w-12 mx-auto mb-3 opacity-30" />
            {t.noResults}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            {filtered.map(tool => (
              <button
                key={tool.id}
                onClick={() => onSelect(tool.id)}
                className="group glass-strong rounded-2xl sm:rounded-3xl p-4 sm:p-5 text-start transition-all hover:scale-[1.02] hover:-translate-y-1 relative overflow-hidden"
              >
                {/* Background glow */}
                <div className={`absolute -top-12 -end-12 w-32 h-32 rounded-full bg-gradient-to-br ${tool.gradient} opacity-20 blur-2xl group-hover:opacity-40 transition-opacity`} />

                {tool.badge && (
                  <span className={`absolute top-3 end-3 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    tool.badge === "new"
                      ? "bg-emerald-500 text-white"
                      : "bg-gradient-to-r from-amber-400 to-orange-500 text-white"
                  }`}>
                    {tool.badge === "new" ? t.newFeature : "⭐"}
                  </span>
                )}

                <div className="relative space-y-3">
                  <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-br ${tool.gradient} flex items-center justify-center shadow-lg group-hover:scale-110 group-hover:rotate-3 transition-all`}>
                    <tool.icon className="h-6 w-6 sm:h-7 sm:w-7 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-base sm:text-lg">{t[tool.name as keyof typeof t]}</h3>
                    <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 line-clamp-2 mt-1">
                      {t[tool.desc as keyof typeof t]}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 text-xs font-medium text-violet-600 dark:text-violet-400 opacity-0 group-hover:opacity-100 transition-opacity">
                    {t.process}
                    <ArrowLeft className="h-3 w-3 flip-on-rtl" />
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </section>

      {/* Stats */}
      <section className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        {[
          { num: "18+", label: "ابزار حرفه‌ای" },
          { num: "10", label: "زبان زنده دنیا" },
          { num: "100%", label: "خصوصی و امن" },
          { num: "0", label: "هزینه — همیشه رایگان" },
        ].map((s, i) => (
          <div key={i} className="glass-strong rounded-2xl p-3 sm:p-4 text-center">
            <p className="text-2xl sm:text-3xl font-black bg-gradient-to-r from-violet-600 to-pink-600 bg-clip-text text-transparent">{s.num}</p>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1">{s.label}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
