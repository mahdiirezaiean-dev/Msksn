declare module "arabic-persian-reshaper" {
  export function reshape(text: string): string;
  const _default: { reshape: (text: string) => string };
  export default _default;
}

declare module "qrcode" {
  export function toDataURL(text: string, opts?: any): Promise<string>;
  export function toCanvas(canvas: any, text: string, opts?: any): Promise<void>;
}
