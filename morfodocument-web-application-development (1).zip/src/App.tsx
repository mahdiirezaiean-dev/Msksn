import { useState, lazy, Suspense, useEffect } from "react";
import { Header } from "./components/Header";
import { ToastContainer } from "./components/Toast";
import { useAppState, setLocale } from "./store";
import { translations } from "./i18n";
import { HomePage } from "./pages/HomePage";
import { AboutPage } from "./pages/AboutPage";
import { ContactPage } from "./pages/ContactPage";
import { Loader2 } from "lucide-react";

const PdfReader = lazy(() => import("./tools/PdfReader").then(m => ({ default: m.PdfReader })));
const MergePdf = lazy(() => import("./tools/PdfEditor").then(m => ({ default: m.MergePdf })));
const SplitPdf = lazy(() => import("./tools/PdfEditor").then(m => ({ default: m.SplitPdf })));
const TextToPdf = lazy(() => import("./tools/PdfEditor").then(m => ({ default: m.TextToPdf })));
const Watermark = lazy(() => import("./tools/Watermark").then(m => ({ default: m.Watermark })));
const CompressImage = lazy(() => import("./tools/MediaTools").then(m => ({ default: m.CompressImage })));
const CompressPdf = lazy(() => import("./tools/MediaTools").then(m => ({ default: m.CompressPdf })));
const PdfToImages = lazy(() => import("./tools/MediaTools").then(m => ({ default: m.PdfToImages })));
const ImagesToPdf = lazy(() => import("./tools/MediaTools").then(m => ({ default: m.ImagesToPdf })));
const OcrTool = lazy(() => import("./tools/OcrTool").then(m => ({ default: m.OcrTool })));
const SignTool = lazy(() => import("./tools/SignTool").then(m => ({ default: m.SignTool })));
const ScanTool = lazy(() => import("./tools/ScanTool").then(m => ({ default: m.ScanTool })));
const LockPdf = lazy(() => import("./tools/AdvancedTools").then(m => ({ default: m.LockPdf })));
const MetadataTool = lazy(() => import("./tools/AdvancedTools").then(m => ({ default: m.MetadataTool })));
const PageNumberTool = lazy(() => import("./tools/AdvancedTools").then(m => ({ default: m.PageNumberTool })));
const QrTool = lazy(() => import("./tools/AdvancedTools").then(m => ({ default: m.QrTool })));
const CompareTool = lazy(() => import("./tools/AdvancedTools").then(m => ({ default: m.CompareTool })));
const FormBuilder = lazy(() => import("./tools/FormBuilder").then(m => ({ default: m.FormBuilder })));
const HistoryTool = lazy(() => import("./tools/HistoryTool").then(m => ({ default: m.HistoryTool })));

const TOOL_TITLES: Record<string, string> = {
  "pdf-reader": "toolPdfReader",
  "scan": "toolScan",
  "pdf-to-image": "toolPdfToImage",
  "image-to-pdf": "toolImageToPdf",
  "split": "toolSplit",
  "merge": "toolMerge",
  "text-to-pdf": "toolTextToPdf",
  "compress": "toolCompress",
  "watermark": "toolWatermark",
  "ocr": "toolOcr",
  "sign": "toolSign",
  "lock": "toolLock",
  "metadata": "toolMetadata",
  "page-number": "toolPageNum",
  "compare": "toolCompare",
  "form": "toolForm",
  "qr": "toolQr",
  "history": "toolHistory",
};

const TOOL_COMPONENTS: Record<string, React.ComponentType> = {
  "pdf-reader": PdfReader as any,
  "scan": ScanTool as any,
  "pdf-to-image": PdfToImages as any,
  "image-to-pdf": ImagesToPdf as any,
  "split": SplitPdf as any,
  "merge": MergePdf as any,
  "text-to-pdf": TextToPdf as any,
  "compress": CompressImage as any,  // default; user can pick image or PDF
  "watermark": Watermark as any,
  "ocr": OcrTool as any,
  "sign": SignTool as any,
  "lock": LockPdf as any,
  "metadata": MetadataTool as any,
  "page-number": PageNumberTool as any,
  "compare": CompareTool as any,
  "form": FormBuilder as any,
  "qr": QrTool as any,
  "history": HistoryTool as any,
};

export default function App() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [page, setPage] = useState<"home" | "about" | "contact" | string>("home");
  const [compressMode, setCompressMode] = useState<"image" | "pdf">("image");

  // Auto-detect browser language on first visit (only if user hasn't chosen)
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const userSet = localStorage.getItem("morfo-state-v1");
      if (!userSet) {
        const browserLang = navigator.language.split("-")[0];
        const supported = ["fa", "en", "ar", "es", "fr", "zh", "hi", "pt", "ru", "de"];
        if (supported.includes(browserLang)) {
          setLocale(browserLang as any);
        } else {
          setLocale("fa"); // default Persian
        }
      }
    } catch {}
  }, []);

  // Compress has sub-mode (image or PDF)
  const ToolComponent = page === "compress"
    ? (compressMode === "pdf" ? CompressPdf : CompressImage)
    : TOOL_COMPONENTS[page];

  const renderPage = () => {
    if (page === "home") return <HomePage onSelect={(id) => setPage(id)} />;
    if (page === "about") return <AboutPage />;
    if (page === "contact") return <ContactPage />;
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3 flex-wrap">
          <button onClick={() => setPage("home")} className="btn-secondary text-sm flex items-center gap-1">
            {t.home}
          </button>
          <h2 className="text-xl sm:text-2xl font-bold">
            {t[TOOL_TITLES[page] as keyof typeof t] || page}
          </h2>
        </div>
        {page === "compress" && (
          <div className="grid grid-cols-2 gap-2 max-w-md">
            <button
              onClick={() => setCompressMode("image")}
              className={`btn-secondary !py-2 ${compressMode === "image" ? "!bg-violet-500 !text-white" : ""}`}
            >{t.compressImage}</button>
            <button
              onClick={() => setCompressMode("pdf")}
              className={`btn-secondary !py-2 ${compressMode === "pdf" ? "!bg-violet-500 !text-white" : ""}`}
            >{t.compressPdf}</button>
          </div>
        )}
        <Suspense fallback={
          <div className="flex items-center justify-center py-20 gap-2 text-slate-500">
            <Loader2 className="h-5 w-5 animate-spin" />
            {t.loading}
          </div>
        }>
          {ToolComponent && <ToolComponent />}
        </Suspense>
      </div>
    );
  };

  return (
    <div className="min-h-screen relative">
      <div className="aurora" />
      <div className="aurora aurora-2" />
      <Header onNavigate={setPage} current={page === "home" || page === "about" || page === "contact" ? page : "tool"} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
        {renderPage()}
      </main>
      <footer className="border-t border-white/20 dark:border-white/5 mt-12 sm:mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8 text-center space-y-2">
          <p className="text-sm font-semibold bg-gradient-to-r from-violet-600 to-pink-600 bg-clip-text text-transparent">MorfoDocument</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">{t.copyright}</p>
        </div>
      </footer>
      <ToastContainer />
    </div>
  );
}
