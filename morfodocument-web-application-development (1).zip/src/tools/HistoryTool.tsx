import { useState, useEffect } from "react";
import { useAppState, getHistory, clearHistory, HistoryItem } from "../store";
import { translations } from "../i18n";
import { Trash2, FileText, Merge, Scissors, Type, Image, Droplet, ScanLine, Edit, Pen, Hash, History as HistoryIcon } from "lucide-react";

const ICONS: Record<string, any> = {
  merge: Merge, split: Scissors, extract: Scissors, "text2pdf": Type, "pdf2image": Image, "image2pdf": Image,
  "compress-image": Droplet, "compress-pdf": Droplet, watermark: Droplet, ocr: ScanLine, sign: Pen,
  metadata: Edit, pagenum: Hash, scan: ScanLine, lock: Edit, form: Edit, qr: Hash, redact: Edit, compare: Edit,
};

const NAMES: Record<string, string> = {
  merge: "Merge PDF", split: "Split PDF", extract: "Extract Pages", text2pdf: "Text to PDF",
  "pdf2image": "PDF to Image", "image2pdf": "Images to PDF", "compress-image": "Compress Image",
  "compress-pdf": "Compress PDF", watermark: "Watermark", ocr: "OCR", sign: "Sign", metadata: "Metadata",
  pagenum: "Page Numbers", scan: "Scan", lock: "Lock", form: "Form", qr: "QR", redact: "Redact", compare: "Compare",
};

export function HistoryTool() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [items, setItems] = useState<HistoryItem[]>([]);

  useEffect(() => {
    setItems(getHistory());
    const onUpdate = () => setItems(getHistory());
    window.addEventListener("morfo-history-updated", onUpdate);
    return () => window.removeEventListener("morfo-history-updated", onUpdate);
  }, []);

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleString(locale === "fa" ? "fa-IR" : locale);
  };

  return (
    <div className="space-y-4">
      {items.length === 0 ? (
        <div className="glass-strong rounded-3xl p-12 text-center">
          <HistoryIcon className="h-12 w-12 text-slate-400 mx-auto mb-3" />
          <p className="text-slate-500">{t.noHistory}</p>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-500">{items.length} {t.recentFiles}</p>
            <button onClick={() => { clearHistory(); }} className="btn-secondary text-sm flex items-center gap-1">
              <Trash2 className="h-3.5 w-3.5" />{t.clearHistory}
            </button>
          </div>
          <div className="space-y-2">
            {items.map(item => {
              const Icon = ICONS[item.tool] || FileText;
              return (
                <div key={item.id} className="glass rounded-2xl p-3 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">{item.name}</p>
                    <p className="text-xs text-slate-500">
                      {NAMES[item.tool] || item.tool} • {formatTime(item.timestamp)}
                    </p>
                  </div>
                  <span className="text-xs text-slate-500">{(item.size / 1024).toFixed(1)} KB</span>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
