import { useState, useRef, useEffect } from "react";
import { PDFDocument } from "pdf-lib";
import { useAppState } from "../store";
import { translations } from "../i18n";
import { toast } from "../components/Toast";
import { downloadBlob, bytesToBlob } from "../utils";
import { addHistory } from "../store";
import { Loader2, Camera, Image as ImageIcon, Download, Trash2, ArrowUp, ArrowDown } from "lucide-react";

interface ScanPage {
  id: string;
  original: string; // dataURL
  processed: string; // dataURL
  corners?: { tl: { x: number; y: number }; tr: any; bl: any; br: any };
}

export function ScanTool() {
  const { locale } = useAppState();
  const t = translations[locale];
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [pages, setPages] = useState<ScanPage[]>([]);
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<"camera" | "gallery" | "review">("gallery");
  const [bw, setBw] = useState(false);
  const [contrast, setContrast] = useState(1.2);
  const [removeShadow, setRemoveShadow] = useState(true);

  useEffect(() => {
    return () => {
      if (stream) stream.getTracks().forEach(t => t.stop());
    };
  }, [stream]);

  const startCamera = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" }, width: { ideal: 1920 }, height: { ideal: 1080 } },
        audio: false,
      });
      setStream(s);
      if (videoRef.current) {
        videoRef.current.srcObject = s;
        videoRef.current.play();
      }
      setMode("camera");
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
  };

  const capture = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const v = videoRef.current;
    const c = canvasRef.current;
    c.width = v.videoWidth;
    c.height = v.videoHeight;
    const ctx = c.getContext("2d")!;
    ctx.drawImage(v, 0, 0);
    const data = c.toDataURL("image/jpeg", 0.85);
    addPage(data);
    toast.show("success", "✓");
  };

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => addPage(reader.result as string);
    reader.readAsDataURL(file);
  };

  const addPage = (data: string) => {
    const page: ScanPage = { id: Math.random().toString(36).slice(2), original: data, processed: data };
    processImage(page).then(p => {
      setPages(prev => prev.map(x => x.id === page.id ? p : x));
    });
    setPages(prev => [...prev, page]);
    setMode("review");
  };

  const processImage = async (page: ScanPage) => {
    return new Promise<ScanPage>((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const maxW = 2000;
        const scale = Math.min(1, maxW / img.width);
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        const ctx = canvas.getContext("2d")!;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const d = data.data;
        for (let i = 0; i < d.length; i += 4) {
          let r = d[i], g = d[i + 1], b = d[i + 2];
          if (bw) {
            const gray = 0.299 * r + 0.587 * g + 0.114 * b;
            r = g = b = gray;
          }
          // Contrast
          r = Math.min(255, Math.max(0, (r - 128) * contrast + 128));
          g = Math.min(255, Math.max(0, (g - 128) * contrast + 128));
          b = Math.min(255, Math.max(0, (b - 128) * contrast + 128));
          // Shadow removal (simple)
          if (removeShadow) {
            const lum = 0.299 * r + 0.587 * g + 0.114 * b;
            const shadow = Math.max(0, 60 - lum) * 0.3;
            r = Math.min(255, r + shadow);
            g = Math.min(255, g + shadow);
            b = Math.min(255, b + shadow);
          }
          d[i] = r; d[i + 1] = g; d[i + 2] = b;
        }
        ctx.putImageData(data, 0, 0);
        resolve({ ...page, processed: canvas.toDataURL("image/jpeg", 0.85) });
      };
      img.src = page.original;
    });
  };

  useEffect(() => {
    pages.forEach(p => {
      processImage(p).then(updated => {
        setPages(prev => prev.map(x => x.id === p.id ? updated : x));
      });
    });
    // eslint-disable-next-line
  }, [bw, contrast, removeShadow]);

  const reorder = (idx: number, dir: -1 | 1) => {
    const arr = [...pages];
    const t2 = idx + dir;
    if (t2 < 0 || t2 >= arr.length) return;
    [arr[idx], arr[t2]] = [arr[t2], arr[idx]];
    setPages(arr);
  };

  const remove = (id: string) => setPages(pages.filter(p => p.id !== id));

  const build = async () => {
    if (pages.length === 0) return;
    setLoading(true);
    try {
      const pdf = await PDFDocument.create();
      for (const p of pages) {
        const buf = await fetch(p.processed).then(r => r.arrayBuffer());
        const jpg = await pdf.embedJpg(buf);
        const page = pdf.addPage([jpg.width, jpg.height]);
        page.drawImage(jpg, { x: 0, y: 0, width: jpg.width, height: jpg.height });
      }
      const bytes = await pdf.save();
      downloadBlob(bytesToBlob(bytes, "application/pdf"), "scanned.pdf");
      addHistory({ name: "scanned.pdf", tool: "scan", size: bytes.byteLength });
      toast.show("success", t.downloaded);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  return (
    <div className="space-y-4">
      {mode === "gallery" && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <button onClick={startCamera} className="glass-strong rounded-2xl p-6 hover:scale-105 transition-transform flex flex-col items-center gap-2">
              <Camera className="h-10 w-10 text-violet-500" />
              <span className="font-semibold">{t.scanCamera}</span>
            </button>
            <label className="glass-strong rounded-2xl p-6 hover:scale-105 transition-transform flex flex-col items-center gap-2 cursor-pointer">
              <ImageIcon className="h-10 w-10 text-pink-500" />
              <span className="font-semibold">{t.scanGallery}</span>
              <input type="file" accept="image/*" multiple onChange={onFile} className="hidden" />
            </label>
          </div>
          {pages.length > 0 && (
            <button onClick={() => setMode("review")} className="btn-primary w-full">📄 {pages.length} {t.pageCount}</button>
          )}
        </div>
      )}

      {mode === "camera" && (
        <div className="space-y-3">
          <div className="relative bg-black rounded-2xl overflow-hidden aspect-[3/4] sm:aspect-video">
            <video ref={videoRef} className="w-full h-full object-cover" playsInline muted />
            {/* Corner guides */}
            <div className="absolute inset-8 border-2 border-white/60 rounded-lg pointer-events-none">
              <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-violet-400 rounded-tl" />
              <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-violet-400 rounded-tr" />
              <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-violet-400 rounded-bl" />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-violet-400 rounded-br" />
            </div>
          </div>
          <canvas ref={canvasRef} className="hidden" />
          <div className="flex gap-2">
            <button onClick={() => { stream?.getTracks().forEach(t => t.stop()); setStream(null); setMode("gallery"); }} className="btn-secondary flex-1">{t.back}</button>
            <button onClick={capture} className="btn-primary flex-1 flex items-center justify-center gap-2">
              <Camera className="h-5 w-5" />
              {t.scanCapture}
            </button>
          </div>
        </div>
      )}

      {mode === "review" && (
        <div className="space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <button onClick={() => setMode("gallery")} className="btn-secondary text-sm">{t.back}</button>
            <span className="text-sm text-slate-500">{pages.length} {t.pageCount}</span>
            <div className="flex-1" />
            <button onClick={() => setBw(!bw)} className={`btn-secondary !py-2 !px-3 text-sm ${bw ? "!bg-violet-500 !text-white" : ""}`}>
              {t.scanBw}
            </button>
            <button onClick={() => setRemoveShadow(!removeShadow)} className={`btn-secondary !py-2 !px-3 text-sm ${removeShadow ? "!bg-violet-500 !text-white" : ""}`}>
              {t.scanShadow}
            </button>
          </div>
          <label className="block">
            <span className="text-xs">{t.scanContrast}: {contrast.toFixed(2)}</span>
            <input type="range" min="0.5" max="2" step="0.05" value={contrast} onChange={(e) => setContrast(+e.target.value)} className="mt-1" />
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {pages.map((p, i) => (
              <div key={p.id} className="glass rounded-2xl p-2 relative group">
                <img src={p.processed} className="w-full aspect-[3/4] object-cover rounded-lg" alt="" />
                <div className="absolute inset-2 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center gap-1">
                  <button onClick={() => reorder(i, -1)} className="p-1.5 rounded bg-white/80"><ArrowUp className="h-3 w-3" /></button>
                  <button onClick={() => reorder(i, 1)} className="p-1.5 rounded bg-white/80"><ArrowDown className="h-3 w-3" /></button>
                  <button onClick={() => remove(p.id)} className="p-1.5 rounded bg-red-500 text-white"><Trash2 className="h-3 w-3" /></button>
                </div>
                <span className="absolute top-3 start-3 bg-black/60 text-white text-xs px-2 py-0.5 rounded">{i + 1}</span>
              </div>
            ))}
          </div>
          <button onClick={build} disabled={loading || pages.length === 0} className="btn-primary w-full flex items-center justify-center gap-2">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
            {t.scanFinish} ({pages.length})
          </button>
        </div>
      )}
    </div>
  );
}
