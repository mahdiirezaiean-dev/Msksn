import { useState, useEffect } from "react";
import { PDFDocument, rgb, degrees } from "pdf-lib";
import fontkit from "@pdf-lib/fontkit";
import { useAppState } from "../store";
import { translations } from "../i18n";
import { DropZone } from "../components/DropZone";
import { toast } from "../components/Toast";
import { downloadBlob, readFileAsArrayBuffer, bytesToBlob, isRTL } from "../utils";
import { addHistory } from "../store";
import { Loader2, Download } from "lucide-react";
import { reshape } from "arabic-persian-reshaper";

const FONT_URL = "https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@33.003/fonts/webfonts/Vazirmatn-Regular.woff2";
let cached: ArrayBuffer | null = null;
async function getFont() {
  if (cached) return cached;
  const r = await fetch(FONT_URL);
  cached = await r.arrayBuffer();
  return cached;
}

export function Watermark() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [file, setFile] = useState<File | null>(null);
  const [text, setText] = useState("محرمانه");
  const [opacity, setOpacity] = useState(0.3);
  const [size, setSize] = useState(48);
  const [angle, setAngle] = useState(-30);
  const [color, setColor] = useState("#8b5cf6");
  const [position, setPosition] = useState<"center" | "tile">("center");
  const [loading, setLoading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const hexToRgb = (hex: string) => {
    const r = parseInt(hex.slice(1, 3), 16) / 255;
    const g = parseInt(hex.slice(3, 5), 16) / 255;
    const b = parseInt(hex.slice(5, 7), 16) / 255;
    return rgb(r, g, b);
  };

  const generatePreview = async () => {
    if (!file) return;
    try {
      const pdfjs: any = await import("pdfjs-dist");
      const buf = await file.arrayBuffer();
      const doc = await pdfjs.getDocument({ data: buf.slice(0) }).promise;
      const page = await doc.getPage(1);
      const viewport = page.getViewport({ scale: 1.0 });
      const canvas = document.createElement("canvas");
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      const ctx = canvas.getContext("2d")!;
      await page.render({ canvas, canvasContext: ctx, viewport } as any).promise;

      // Draw watermark overlay
      const useRTL = isRTL(text);
      const displayText = useRTL ? reshape(text) : text;
      ctx.save();
      ctx.globalAlpha = opacity;
      ctx.translate(viewport.width / 2, viewport.height / 2);
      ctx.rotate((angle * Math.PI) / 180);
      ctx.fillStyle = color;
      ctx.font = `bold ${size}px Vazirmatn, sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.direction = useRTL ? "rtl" : "ltr";
      ctx.fillText(displayText, 0, 0);
      ctx.restore();

      setPreviewUrl(canvas.toDataURL("image/jpeg", 0.7));
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
  };

  useEffect(() => {
    if (file) generatePreview();
    // eslint-disable-next-line
  }, [file, text, opacity, size, angle, color]);

  const process = async () => {
    if (!file || !text) return;
    setLoading(true);
    try {
      const buf = await readFileAsArrayBuffer(file);
      const doc = await PDFDocument.load(buf, { ignoreEncryption: true });
      doc.registerFontkit(fontkit);
      const font = await doc.embedFont(await getFont(), { subset: true });
      const useRTL = isRTL(text);
      const displayText = useRTL ? reshape(text) : text;
      const textWidth = font.widthOfTextAtSize(displayText, size);
      const colorRgb = hexToRgb(color);

      for (const page of doc.getPages()) {
        const { width, height } = page.getSize();
        if (position === "center") {
          page.drawText(displayText, {
            x: width / 2 - textWidth / 2,
            y: height / 2,
            size,
            font,
            color: colorRgb,
            opacity,
            rotate: degrees(angle),
          });
        } else {
          // Tile
          const stepX = textWidth + 100;
          const stepY = size * 4;
          for (let y = 0; y < height + stepY; y += stepY) {
            for (let x = -stepX; x < width + stepX; x += stepX) {
              page.drawText(displayText, {
                x, y, size, font, color: colorRgb, opacity: opacity * 0.6, rotate: degrees(angle),
              });
            }
          }
        }
      }

      const bytes = await doc.save();
      downloadBlob(bytesToBlob(bytes, "application/pdf"), "watermarked.pdf");
      addHistory({ name: "watermarked.pdf", tool: "watermark", size: bytes.byteLength });
      toast.show("success", t.downloaded);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  if (!file) return <DropZone accept="application/pdf" onFiles={(fs) => fs[0] && setFile(fs[0])} hint={t.dragDrop} />;

  return (
    <div className="space-y-4">
      <div className="grid lg:grid-cols-2 gap-4">
        {/* Controls */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <button onClick={() => setFile(null)} className="btn-secondary text-sm">{t.back}</button>
          </div>
          <label className="block">
            <span className="text-sm font-medium">{t.watermarkText}</span>
            <input value={text} onChange={(e) => setText(e.target.value)} className="input mt-1" />
          </label>
          <label className="block">
            <span className="text-sm font-medium">{t.color}</span>
            <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="input mt-1 h-12" />
          </label>
          <label className="block">
            <span className="text-sm font-medium">{t.opacity}: {Math.round(opacity * 100)}%</span>
            <input type="range" min="0.05" max="1" step="0.05" value={opacity} onChange={(e) => setOpacity(+e.target.value)} className="mt-1" />
          </label>
          <label className="block">
            <span className="text-sm font-medium">{t.size}: {size}px</span>
            <input type="range" min="12" max="120" value={size} onChange={(e) => setSize(+e.target.value)} className="mt-1" />
          </label>
          <label className="block">
            <span className="text-sm font-medium">{t.angle}: {angle}°</span>
            <input type="range" min="-90" max="90" value={angle} onChange={(e) => setAngle(+e.target.value)} className="mt-1" />
          </label>
          <div className="flex gap-2">
            <button onClick={() => setPosition("center")} className={`flex-1 btn-secondary text-sm ${position === "center" ? "!bg-violet-500 !text-white" : ""}`}>{t.center}</button>
            <button onClick={() => setPosition("tile")} className={`flex-1 btn-secondary text-sm ${position === "tile" ? "!bg-violet-500 !text-white" : ""}`}>Tile</button>
          </div>
          <button onClick={process} disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
            {t.process} & {t.download}
          </button>
        </div>

        {/* Preview */}
        <div className="glass-strong rounded-2xl p-3 sm:p-4 max-h-[500px] overflow-auto">
          {previewUrl ? (
            <img src={previewUrl} alt="Preview" className="w-full rounded-lg shadow" />
          ) : (
            <div className="flex items-center justify-center h-64 text-slate-400">{t.preview}...</div>
          )}
        </div>
      </div>
    </div>
  );
}
