import { useState, useRef, useEffect } from "react";
import SignaturePad from "signature_pad";
import { PDFDocument } from "pdf-lib";
import { useAppState } from "../store";
import { translations } from "../i18n";
import { DropZone } from "../components/DropZone";
import { toast } from "../components/Toast";
import { downloadBlob, readFileAsArrayBuffer, bytesToBlob } from "../utils";
import { addHistory } from "../store";
import { Loader2, Download, Eraser } from "lucide-react";

export function SignTool() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [file, setFile] = useState<File | null>(null);
  const [pageCount, setPageCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageDims, setPageDims] = useState<{ w: number; h: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [penColor, setPenColor] = useState("#000000");
  const [thumb, setThumb] = useState<string | null>(null);
  const [signatureData, setSignatureData] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sigPadRef = useRef<SignaturePad | null>(null);
  const pageCanvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (canvasRef.current) {
      sigPadRef.current = new SignaturePad(canvasRef.current, {
        backgroundColor: "rgba(255,255,255,0)",
        penColor,
        minWidth: 1.5,
        maxWidth: 3,
      });
      sigPadRef.current.addEventListener("endStroke", () => {
        setSignatureData(sigPadRef.current?.toDataURL("image/png") || null);
      });
    }
    return () => sigPadRef.current?.off();
    // eslint-disable-next-line
  }, []);

  useEffect(() => {
    if (sigPadRef.current) sigPadRef.current.penColor = penColor;
  }, [penColor]);

  const loadFile = async (f: File) => {
    setFile(f);
    setSignatureData(null);
    sigPadRef.current?.clear();
    try {
      const pdfjs: any = await import("pdfjs-dist");
      const buf = await f.arrayBuffer();
      const doc = await pdfjs.getDocument({ data: buf.slice(0) }).promise;
      setPageCount(doc.numPages);
      setCurrentPage(1);
      await renderPage(doc, 1);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
  };

  const renderPage = async (doc: any, n: number) => {
    const page = await doc.getPage(n);
    const viewport = page.getViewport({ scale: 1.0 });
    setPageDims({ w: viewport.width, h: viewport.height });
    if (pageCanvasRef.current) {
      pageCanvasRef.current.width = viewport.width;
      pageCanvasRef.current.height = viewport.height;
      const ctx = pageCanvasRef.current.getContext("2d")!;
      await page.render({ canvas: pageCanvasRef.current, canvasContext: ctx, viewport } as any).promise;
      setThumb(pageCanvasRef.current.toDataURL("image/jpeg", 0.6));
    }
  };

  const goPage = async (delta: number) => {
    if (!file) return;
    const newPage = Math.max(1, Math.min(pageCount, currentPage + delta));
    if (newPage === currentPage) return;
    setCurrentPage(newPage);
    const pdfjs: any = await import("pdfjs-dist");
    const buf = await file.arrayBuffer();
    const doc = await pdfjs.getDocument({ data: buf.slice(0) }).promise;
    await renderPage(doc, newPage);
  };

  const process = async () => {
    if (!file || !signatureData || !pageDims) {
      toast.show("warning", t.fillAllFields);
      return;
    }
    setLoading(true);
    try {
      const buf = await readFileAsArrayBuffer(file);
      const doc = await PDFDocument.load(buf, { ignoreEncryption: true });
      const sigImg = await doc.embedPng(signatureData);

      // Place signature on the current page (bottom right)
      const page = doc.getPage(currentPage - 1);
      const { width } = page.getSize();
      const sigW = 150;
      const sigH = (sigImg.height / sigImg.width) * sigW;
      page.drawImage(sigImg, {
        x: width - sigW - 40,
        y: 40,
        width: sigW,
        height: sigH,
      });

      const bytes = await doc.save();
      downloadBlob(bytesToBlob(bytes, "application/pdf"), "signed.pdf");
      addHistory({ name: "signed.pdf", tool: "sign", size: bytes.byteLength });
      toast.show("success", t.downloaded);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  if (!file) return <DropZone accept="application/pdf" onFiles={(fs) => fs[0] && loadFile(fs[0])} hint={t.dragDrop} />;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        <button onClick={() => setFile(null)} className="btn-secondary text-sm">{t.back}</button>
        <span className="text-sm text-slate-500">{currentPage} / {pageCount}</span>
        <button onClick={() => goPage(-1)} className="btn-secondary text-sm !py-1 !px-2">‹</button>
        <button onClick={() => goPage(1)} className="btn-secondary text-sm !py-1 !px-2">›</button>
        <div className="flex-1" />
        <input type="color" value={penColor} onChange={(e) => setPenColor(e.target.value)} className="w-8 h-8 rounded" />
        <button onClick={() => sigPadRef.current?.clear()} className="btn-secondary !py-2 !px-3 text-sm flex items-center gap-1">
          <Eraser className="h-3.5 w-3.5" />{t.reset}
        </button>
      </div>

      <div className="grid lg:grid-cols-[1fr,300px] gap-4">
        <div ref={containerRef} className="glass-strong rounded-2xl p-3 sm:p-4 bg-slate-100 dark:bg-slate-900 flex justify-center">
          {thumb && <img src={thumb} className="max-w-full shadow-lg" alt="Page preview" />}
          <canvas ref={pageCanvasRef} className="hidden" />
        </div>

        <div className="space-y-3">
          <div className="glass-strong rounded-2xl p-3">
            <p className="text-sm font-semibold mb-2">✍️ {t.toolSign}</p>
            <div className="bg-white rounded-xl overflow-hidden">
              <canvas ref={canvasRef} className="w-full block touch-none" style={{ aspectRatio: "2/1" }} width={500} height={250} />
            </div>
            <p className="text-xs text-slate-500 mt-2">امضا در گوشه پایین-راست صفحه فعلی قرار می‌گیرد</p>
          </div>
          <button onClick={process} disabled={loading || !signatureData} className="btn-primary w-full flex items-center justify-center gap-2">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
            {t.process} & {t.download}
          </button>
        </div>
      </div>
    </div>
  );
}
