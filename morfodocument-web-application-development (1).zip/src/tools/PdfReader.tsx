import { useState, useRef, useEffect } from "react";
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Search, Loader2 } from "lucide-react";
import * as pdfjsLib from "pdfjs-dist";
import workerSrc from "pdfjs-dist/build/pdf.worker.mjs?url";
import { useAppState } from "../store";
import { translations } from "../i18n";
import { DropZone } from "../components/DropZone";
import { toast } from "../components/Toast";

// Configure worker (matching version)
pdfjsLib.GlobalWorkerOptions.workerSrc = workerSrc;

export function PdfReader() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [file, setFile] = useState<File | null>(null);
  const [pdf, setPdf] = useState<pdfjsLib.PDFDocumentProxy | null>(null);
  const [pageNum, setPageNum] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [scale, setScale] = useState(1.2);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [hasTextLayer, setHasTextLayer] = useState(true);
  const [password, setPassword] = useState("");
  const [needsPassword, setNeedsPassword] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const textLayerRef = useRef<HTMLDivElement>(null);
  const renderTaskRef = useRef<any>(null);

  useEffect(() => {
    return () => { if (renderTaskRef.current) renderTaskRef.current.cancel(); };
  }, []);

  const loadFile = async (f: File) => {
    setLoading(true);
    setFile(f);
    try {
      const buf = await f.arrayBuffer();
      const loadingTask = pdfjsLib.getDocument({ data: buf, password: password || undefined });
      loadingTask.onPassword = () => { setNeedsPassword(true); setLoading(false); };
      const p = await loadingTask.promise;
      setPdf(p);
      setTotalPages(p.numPages);
      setPageNum(1);
      setNeedsPassword(false);
      setLoading(false);
    } catch (e: any) {
      if (e?.name === "PasswordException") {
        setNeedsPassword(true);
      } else {
        toast.show("error", t.error + ": " + (e?.message || ""));
      }
      setLoading(false);
    }
  };

  const renderPage = async (n: number, s: number) => {
    if (!pdf || !canvasRef.current || !textLayerRef.current) return;
    if (renderTaskRef.current) {
      try { await renderTaskRef.current.cancel(); } catch {}
    }

    const page = await pdf.getPage(n);
    const viewport = page.getViewport({ scale: s });

    const canvas = canvasRef.current;
    const context = canvas.getContext("2d");
    if (!context) return;

    // High-DPI rendering
    const dpr = window.devicePixelRatio || 1;
    canvas.width = viewport.width * dpr;
    canvas.height = viewport.height * dpr;
    canvas.style.width = viewport.width + "px";
    canvas.style.height = viewport.height + "px";
    context.scale(dpr, dpr);

    const task = page.render({ canvas, canvasContext: context, viewport } as any);
    renderTaskRef.current = task;
    try {
      await task.promise;
    } catch (e: any) {
      if (e?.name !== "RenderingCancelledException") throw e;
    }

    // Text layer
    const textContent = await page.getTextContent();
    const textLayerDiv = textLayerRef.current;
    textLayerDiv.innerHTML = "";
    textLayerDiv.style.width = viewport.width + "px";
    textLayerDiv.style.height = viewport.height + "px";

    if (textContent.items.length === 0) {
      setHasTextLayer(false);
    } else {
      setHasTextLayer(true);
      // Manually render text layer for accurate positioning
      const tx = pdfjsLib.Util.transform(viewport.transform, viewport.transform);
      textContent.items.forEach((item: any) => {
        const span = document.createElement("span");
        const tx2 = pdfjsLib.Util.transform(tx, item.transform);
        const fontHeight = Math.hypot(tx2[2], tx2[3]);
        const angle = Math.atan2(tx2[1], tx2[0]);
        span.style.fontSize = `${fontHeight}px`;
        span.style.fontFamily = "sans-serif";
        span.style.position = "absolute";
        span.style.left = `${tx2[4]}px`;
        span.style.top = `${tx2[5] - fontHeight}px`;
        span.style.transform = `rotate(${angle}rad)`;
        span.style.transformOrigin = "0% 0%";
        span.textContent = item.str;
        if ('dir' in item) span.dir = item.dir;
        textLayerDiv.appendChild(span);
      });
    }
  };

  useEffect(() => {
    if (pdf) renderPage(pageNum, scale);
    // eslint-disable-next-line
  }, [pdf, pageNum, scale]);

  if (!file) {
    return (
      <DropZone
        accept="application/pdf"
        onFiles={(files) => files[0] && loadFile(files[0])}
        hint={t.dragDrop + " — PDF"}
      />
    );
  }

  if (needsPassword) {
    return (
      <div className="glass-strong rounded-3xl p-8 max-w-md mx-auto">
        <h3 className="text-lg font-semibold mb-4">{t.pdfPasswordRequired}</h3>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder={t.password}
          className="input mb-3"
        />
        <div className="flex gap-2">
          <button onClick={() => setFile(null)} className="btn-secondary flex-1">{t.back}</button>
          <button onClick={() => loadFile(file)} className="btn-primary flex-1">{t.process}</button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="glass-strong rounded-2xl p-3 sm:p-4 flex flex-wrap items-center gap-2 sm:gap-3">
        <button
          onClick={() => setFile(null)}
          className="btn-secondary !py-2 !px-3 text-sm"
        >
          {t.back}
        </button>

        <div className="flex items-center gap-1 bg-violet-100 dark:bg-violet-900/30 rounded-xl px-2 py-1">
          <button
            disabled={pageNum <= 1}
            onClick={() => setPageNum(p => Math.max(1, p - 1))}
            className="p-2 rounded-lg hover:bg-white dark:hover:bg-slate-800 disabled:opacity-30"
          >
            {locale === "fa" || locale === "ar" ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </button>
          <span className="text-sm font-medium px-2 min-w-[60px] text-center">
            {pageNum} / {totalPages}
          </span>
          <button
            disabled={pageNum >= totalPages}
            onClick={() => setPageNum(p => Math.min(totalPages, p + 1))}
            className="p-2 rounded-lg hover:bg-white dark:hover:bg-slate-800 disabled:opacity-30"
          >
            {locale === "fa" || locale === "ar" ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </button>
        </div>

        <div className="flex items-center gap-1 bg-violet-100 dark:bg-violet-900/30 rounded-xl px-2 py-1">
          <button onClick={() => setScale(s => Math.max(0.5, s - 0.2))} className="p-2 rounded-lg hover:bg-white dark:hover:bg-slate-800">
            <ZoomOut className="h-4 w-4" />
          </button>
          <span className="text-sm font-medium px-2 min-w-[50px] text-center">{Math.round(scale * 100)}%</span>
          <button onClick={() => setScale(s => Math.min(3, s + 0.2))} className="p-2 rounded-lg hover:bg-white dark:hover:bg-slate-800">
            <ZoomIn className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 min-w-[150px] relative">
          <Search className="absolute top-1/2 -translate-y-1/2 start-3 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.search}
            className="input !py-2 !ps-9 text-sm"
          />
        </div>
      </div>

      {!hasTextLayer && (
        <div className="glass rounded-2xl p-3 sm:p-4 text-sm text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800">
          ⚠️ {t.noTextLayer}
        </div>
      )}

      {/* Page viewer */}
      <div ref={containerRef} className="glass-strong rounded-2xl p-4 sm:p-6 overflow-auto max-h-[70vh] flex justify-center bg-slate-100 dark:bg-slate-900">
        {loading ? (
          <div className="flex items-center justify-center h-96 gap-2">
            <Loader2 className="h-6 w-6 animate-spin" />
            <span>{t.loading}</span>
          </div>
        ) : (
          <div className="relative shadow-2xl" style={{ width: "fit-content" }}>
            <canvas ref={canvasRef} className="block bg-white" />
            <div ref={textLayerRef} className="pdf-text-layer" />
          </div>
        )}
      </div>
    </div>
  );
}
