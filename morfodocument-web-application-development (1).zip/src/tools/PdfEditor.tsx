import { useState } from "react";
import { PDFDocument, rgb, degrees } from "pdf-lib";
import fontkit from "@pdf-lib/fontkit";
import { useAppState } from "../store";
import { translations } from "../i18n";
import { DropZone } from "../components/DropZone";
import { toast } from "../components/Toast";
import { downloadBlob, readFileAsArrayBuffer, bytesToBlob } from "../utils";
import { isRTL } from "../utils";
import { addHistory } from "../store";
import { Loader2, Download, Trash2, GripVertical, ArrowUp, ArrowDown, RotateCw } from "lucide-react";
import { reshape } from "arabic-persian-reshaper";

const VAZIRMATN_URL = "https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@33.003/fonts/webfonts/Vazirmatn-Regular.woff2";
let cachedFont: ArrayBuffer | null = null;
let cachedFontBold: ArrayBuffer | null = null;

async function getFont(): Promise<ArrayBuffer> {
  if (cachedFont) return cachedFont;
  const response = await fetch(VAZIRMATN_URL);
  cachedFont = await response.arrayBuffer();
  return cachedFont;
}

void cachedFontBold;

// ============ MERGE PDF ============
export function MergePdf() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [files, setFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);

  const move = (idx: number, dir: -1 | 1) => {
    const newFiles = [...files];
    const target = idx + dir;
    if (target < 0 || target >= newFiles.length) return;
    [newFiles[idx], newFiles[target]] = [newFiles[target], newFiles[idx]];
    setFiles(newFiles);
  };

  const remove = (idx: number) => setFiles(files.filter((_, i) => i !== idx));

  const process = async () => {
    if (files.length < 2) {
      toast.show("warning", t.fillAllFields);
      return;
    }
    setLoading(true);
    try {
      const merged = await PDFDocument.create();
      for (const f of files) {
        const buf = await readFileAsArrayBuffer(f);
        const doc = await PDFDocument.load(buf, { ignoreEncryption: true });
        const pages = await merged.copyPages(doc, doc.getPageIndices());
        pages.forEach(p => merged.addPage(p));
      }
      const bytes = await merged.save();
      downloadBlob(bytesToBlob(bytes, "application/pdf"), "merged.pdf");
      addHistory({ name: "merged.pdf", tool: "merge", size: bytes.byteLength });
      toast.show("success", t.downloaded);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  return (
    <div className="space-y-4">
      <DropZone accept="application/pdf" multiple onFiles={(fs) => setFiles([...files, ...fs])} hint={t.dragDrop} />
      {files.length > 0 && (
        <div className="glass-strong rounded-2xl p-4 space-y-2">
          {files.map((f, i) => (
            <div key={i} className="flex items-center gap-2 bg-white/40 dark:bg-slate-800/40 rounded-xl p-3">
              <GripVertical className="h-4 w-4 text-slate-400" />
              <span className="flex-1 truncate text-sm">{i + 1}. {f.name}</span>
              <button onClick={() => move(i, -1)} className="p-1.5 rounded hover:bg-violet-100 dark:hover:bg-violet-900/30"><ArrowUp className="h-4 w-4" /></button>
              <button onClick={() => move(i, 1)} className="p-1.5 rounded hover:bg-violet-100 dark:hover:bg-violet-900/30"><ArrowDown className="h-4 w-4" /></button>
              <button onClick={() => remove(i)} className="p-1.5 rounded hover:bg-red-100 dark:hover:bg-red-900/30 text-red-500"><Trash2 className="h-4 w-4" /></button>
            </div>
          ))}
        </div>
      )}
      {files.length >= 2 && (
        <button onClick={process} disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
          {t.process} ({files.length} {t.fileSelected})
        </button>
      )}
    </div>
  );
}

// ============ SPLIT PDF ============
export function SplitPdf() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [file, setFile] = useState<File | null>(null);
  const [thumbnails, setThumbnails] = useState<string[]>([]);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [rotations, setRotations] = useState<Record<number, number>>({});
  const [loading, setLoading] = useState(false);
  const [pageCount, setPageCount] = useState(0);

  const loadFile = async (f: File) => {
    setFile(f);
    setSelected(new Set());
    setRotations({});
    setLoading(true);
    try {
      const pdfjs: any = await import("pdfjs-dist");
      const buf = await f.arrayBuffer();
      const doc = await pdfjs.getDocument({ data: buf.slice(0) }).promise;
      setPageCount(doc.numPages);
      const thumbs: string[] = [];
      for (let i = 1; i <= doc.numPages; i++) {
        const page = await doc.getPage(i);
        const viewport = page.getViewport({ scale: 0.3 });
        const canvas = document.createElement("canvas");
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const ctx = canvas.getContext("2d");
        if (!ctx) continue;
        await page.render({ canvas, canvasContext: ctx, viewport } as any).promise;
        thumbs.push(canvas.toDataURL("image/jpeg", 0.6));
      }
      setThumbnails(thumbs);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  const toggle = (idx: number) => {
    const s = new Set(selected);
    s.has(idx) ? s.delete(idx) : s.add(idx);
    setSelected(s);
  };

  const rotate = (idx: number) => {
    setRotations({ ...rotations, [idx]: ((rotations[idx] || 0) + 90) % 360 });
  };

  const process = async (mode: "extract" | "remove") => {
    if (!file) return;
    setLoading(true);
    try {
      const buf = await readFileAsArrayBuffer(file);
      const doc = await PDFDocument.load(buf, { ignoreEncryption: true });
      const indices = Array.from({ length: pageCount }, (_, i) => i);
      const toKeep = mode === "extract"
        ? Array.from(selected).sort((a, b) => a - b)
        : indices.filter(i => !selected.has(i));

      if (toKeep.length === 0) {
        toast.show("warning", t.fillAllFields);
        setLoading(false);
        return;
      }

      const out = await PDFDocument.create();
      for (const idx of toKeep) {
        const [p] = await out.copyPages(doc, [idx]);
        const r = rotations[idx] || 0;
        if (r) p.setRotation(degrees(r));
        out.addPage(p);
      }
      const bytes = await out.save();
      downloadBlob(bytesToBlob(bytes, "application/pdf"), `${mode === "extract" ? "extracted" : "split"}.pdf`);
      addHistory({ name: `${mode}.pdf`, tool: mode, size: bytes.byteLength });
      toast.show("success", t.downloaded);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  if (!file) {
    return <DropZone accept="application/pdf" onFiles={(fs) => fs[0] && loadFile(fs[0])} hint={t.dragDrop} />;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <button onClick={() => setFile(null)} className="btn-secondary text-sm">{t.back}</button>
        <span className="text-sm text-slate-500">{pageCount} {t.pageCount}</span>
      </div>

      {loading ? (
        <div className="flex items-center justify-center p-12 gap-2"><Loader2 className="h-5 w-5 animate-spin" />{t.loading}</div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {thumbnails.map((thumb, i) => (
              <div
                key={i}
                onClick={() => toggle(i)}
                className={`relative glass rounded-xl p-2 cursor-pointer transition-all hover:scale-105 ${selected.has(i) ? "ring-2 ring-violet-500 bg-violet-100 dark:bg-violet-900/40" : ""}`}
                style={{ transform: `rotate(${rotations[i] || 0}deg)` }}
              >
                <div className="aspect-[3/4] bg-white rounded-lg overflow-hidden">
                  <img src={thumb} alt={`Page ${i + 1}`} className="w-full h-full object-contain" />
                </div>
                <div className="flex items-center justify-between mt-1.5 text-xs">
                  <span>{i + 1}</span>
                  <button onClick={(e) => { e.stopPropagation(); rotate(i); }} className="p-1 hover:bg-violet-200 dark:hover:bg-violet-800 rounded">
                    <RotateCw className="h-3 w-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {selected.size > 0 && (
            <div className="flex gap-2 flex-wrap">
              <button onClick={() => setSelected(new Set())} className="btn-secondary flex-1 min-w-[120px]">{t.deselectAll}</button>
              <button onClick={() => process("extract")} className="btn-primary flex-1 min-w-[120px]">
                <Download className="h-4 w-4 inline-block me-1" />{t.extract} ({selected.size})
              </button>
              <button onClick={() => process("remove")} className="btn-primary flex-1 min-w-[120px]" style={{ background: "linear-gradient(135deg, #ef4444, #f97316)" }}>
                <Trash2 className="h-4 w-4 inline-block me-1" />{t.delete} ({selected.size})
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ============ TEXT TO PDF ============
export function TextToPdf() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [text, setText] = useState("");
  const [title, setTitle] = useState("");
  const [fontSize, setFontSize] = useState(14);
  const [loading, setLoading] = useState(false);
  const [direction, setDirection] = useState<"auto" | "rtl" | "ltr">("auto");

  const process = async () => {
    if (!text.trim()) {
      toast.show("warning", t.fillAllFields);
      return;
    }
    setLoading(true);
    try {
      const doc = await PDFDocument.create();
      doc.registerFontkit(fontkit);
      const fontBytes = await getFont();
      const customFont = await doc.embedFont(fontBytes, { subset: true });

      const pageWidth = 595.28; // A4
      const pageHeight = 841.89;
      const margin = 60;
      const lineHeight = fontSize * 1.8;
      const maxWidth = pageWidth - margin * 2;

      const useRTL = direction === "rtl" || (direction === "auto" && isRTL(text));

      // Word wrap considering RTL
      const lines: string[] = [];
      const paragraphs = text.split(/\n/);
      for (const para of paragraphs) {
        if (!para) { lines.push(""); continue; }
        const words = useRTL ? para.split(" ") : para.split(" ");
        let currentLine = "";
        for (const word of words) {
          const test = currentLine ? currentLine + " " + word : word;
          const width = customFont.widthOfTextAtSize(test, fontSize);
          if (width > maxWidth && currentLine) {
            lines.push(currentLine);
            currentLine = word;
          } else {
            currentLine = test;
          }
        }
        if (currentLine) lines.push(currentLine);
      }

      let page = doc.addPage([pageWidth, pageHeight]);
      let y = pageHeight - margin;

      // Title (reshaped)
      if (title) {
        const titleReshaped = reshape(title);
        const titleWidth = customFont.widthOfTextAtSize(titleReshaped, 22);
        const tx = useRTL ? pageWidth - margin - titleWidth : margin;
        page.drawText(titleReshaped, { x: tx, y, size: 22, font: customFont, color: rgb(0.1, 0.1, 0.3) });
        y -= 40;
      }

      for (const line of lines) {
        if (y < margin) {
          page = doc.addPage([pageWidth, pageHeight]);
          y = pageHeight - margin;
        }
        const lineText = useRTL ? reshape(line) : line;
        const w = customFont.widthOfTextAtSize(lineText, fontSize);
        const x = useRTL ? pageWidth - margin - w : margin;
        page.drawText(lineText, { x, y, size: fontSize, font: customFont, color: rgb(0.1, 0.1, 0.2) });
        y -= lineHeight;
      }

      const bytes = await doc.save();
      downloadBlob(bytesToBlob(bytes, "application/pdf"), "text.pdf");
      addHistory({ name: "text.pdf", tool: "text2pdf", size: bytes.byteLength });
      toast.show("success", t.downloaded);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  const insertTemplate = (type: "letter" | "resume" | "invoice") => {
    if (type === "letter") {
      setTitle("نامه اداری");
      setText(`تاریخ: ${new Date().toLocaleDateString("fa-IR")}\n\nبه: مدیر محترم\nاز: [نام شما]\nموضوع: [موضوع نامه]\n\nبا سلام و احترام،\n\nمتن نامه در این بخش قرار می‌گیرد. لطفاً پیام خود را به‌صورت رسمی و حرفه‌ای بنویسید.\n\nبا تشکر،\n[نام و نام خانوادگی]`);
    } else if (type === "resume") {
      setTitle("رزومه");
      setText(`[نام و نام خانوادگی]\n[شماره تماس] | [ایمیل]\n\n═══ سوابق تحصیلی ═══\n\n[مدرک تحصیلی] - [دانشگاه]\n[سال فارغ‌التحصیلی]\n\n═══ سوابق کاری ═══\n\n[عنوان شغلی] - [نام شرکت]\n[سال شروع] - [سال پایان]\n- شرح وظایف و دستاوردها\n\n═══ مهارت‌ها ═══\n\n- مهارت ۱\n- مهارت ۲\n- مهارت ۳`);
    } else {
      setTitle("فاکتور");
      setText(`شماره فاکتور: ${Math.floor(Math.random() * 10000)}\nتاریخ: ${new Date().toLocaleDateString("fa-IR")}\n\nمشتری: [نام مشتری]\n\n═══ اقلام ═══\n\n۱. [محصول/خدمت]      تعداد: ۱      قیمت: ۱۰۰,۰۰۰ تومان\n۲. [محصول/خدمت]      تعداد: ۲      قیمت: ۲۰۰,۰۰۰ تومان\n\n═══ جمع کل: ۳۰۰,۰۰۰ تومان ═══`);
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-2">
        <button onClick={() => insertTemplate("letter")} className="btn-secondary text-sm">{t.toolTextToPdf} — Letter</button>
        <button onClick={() => insertTemplate("resume")} className="btn-secondary text-sm">Resume</button>
        <button onClick={() => insertTemplate("invoice")} className="btn-secondary text-sm">Invoice</button>
      </div>
      <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t.metadataTitle} className="input" />
      <div className="grid grid-cols-2 gap-2">
        <select value={direction} onChange={(e) => setDirection(e.target.value as any)} className="input">
          <option value="auto">{t.auto} - {t.ttsDirection}</option>
          <option value="rtl">{t.rtl}</option>
          <option value="ltr">{t.ltr}</option>
        </select>
        <div className="flex items-center gap-2">
          <span className="text-sm whitespace-nowrap">{t.size}: {fontSize}</span>
          <input type="range" min="10" max="24" value={fontSize} onChange={(e) => setFontSize(+e.target.value)} className="flex-1" />
        </div>
      </div>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder={t.enterText + "..."}
        rows={12}
        dir="auto"
        className="input min-h-[300px] font-mono text-sm"
      />
      <button onClick={process} disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
        {t.process} & {t.download}
      </button>
    </div>
  );
}
