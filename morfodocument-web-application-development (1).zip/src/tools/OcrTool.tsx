import { useState, useEffect } from "react";
import Tesseract from "tesseract.js";
import { useAppState } from "../store";
import { translations } from "../i18n";
import { DropZone } from "../components/DropZone";
import { toast } from "../components/Toast";
import { Copy, Download, Loader2, Check } from "lucide-react";

export function OcrTool() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [lang, setLang] = useState<"fas" | "eng" | "fas+eng">("fas+eng");
  const [copied, setCopied] = useState(false);
  const [preprocessed, setPreprocessed] = useState<string | null>(null);

  useEffect(() => {
    if (file) {
      const url = URL.createObjectURL(file);
      setPreview(url);
      preprocessImage(url);
      return () => URL.revokeObjectURL(url);
    }
  }, [file]);

  const preprocessImage = async (url: string) => {
    const img = new Image();
    img.src = url;
    await new Promise(r => img.onload = r);
    const canvas = document.createElement("canvas");
    const maxW = 1800;
    const scale = Math.min(1, maxW / img.width);
    canvas.width = img.width * scale;
    canvas.height = img.height * scale;
    const ctx = canvas.getContext("2d")!;
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    // Increase contrast and convert to grayscale
    const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const d = data.data;
    for (let i = 0; i < d.length; i += 4) {
      const gray = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      // Contrast enhancement
      const enhanced = Math.min(255, Math.max(0, (gray - 128) * 1.4 + 128));
      d[i] = d[i + 1] = d[i + 2] = enhanced;
    }
    ctx.putImageData(data, 0, 0);
    setPreprocessed(canvas.toDataURL("image/jpeg", 0.85));
  };

  const process = async () => {
    if (!file || !preprocessed) return;
    setLoading(true);
    setText("");
    setProgress(0);
    try {
      const result = await Tesseract.recognize(preprocessed, lang, {
        logger: (m: any) => {
          if (m.status === "recognizing text") setProgress(Math.round(m.progress * 100));
        },
      });
      setText(result.data.text);
      if (!result.data.text.trim()) toast.show("info", t.ocrNoText);
      else toast.show("success", t.success);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  const copy = async () => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
    toast.show("success", t.copied);
  };

  const download = () => {
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "extracted_text.txt";
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!file) return <DropZone accept="image/*" onFiles={(fs) => fs[0] && setFile(fs[0])} hint={t.dragDrop + " — Image"} />;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2 items-center">
        <button onClick={() => setFile(null)} className="btn-secondary text-sm">{t.back}</button>
        <select value={lang} onChange={(e) => setLang(e.target.value as any)} className="input flex-1 min-w-[150px]">
          <option value="fas">{t.ocrFas}</option>
          <option value="eng">{t.ocrEng}</option>
          <option value="fas+eng">{t.ocrBoth}</option>
        </select>
        <button onClick={process} disabled={loading} className="btn-primary flex items-center gap-2">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
          {t.ocrExtract}
        </button>
      </div>

      {loading && (
        <div className="glass-strong rounded-2xl p-4">
          <p className="text-sm text-center mb-2">{t.ocrProgress}: {progress}%</p>
          <div className="h-2 bg-violet-100 dark:bg-violet-900/30 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-violet-500 to-pink-500 transition-all" style={{ width: `${progress}%` }} />
          </div>
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        {preview && (
          <div className="glass-strong rounded-2xl p-3">
            <p className="text-xs mb-2 font-semibold">Original</p>
            <img src={preview} className="w-full rounded-lg" alt="Original" />
          </div>
        )}
        <div className="glass-strong rounded-2xl p-3 flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold">Extracted Text</p>
            <div className="flex gap-1">
              <button onClick={copy} className="p-1.5 rounded hover:bg-violet-100 dark:hover:bg-violet-900/30">
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
              </button>
              <button onClick={download} className="p-1.5 rounded hover:bg-violet-100 dark:hover:bg-violet-900/30">
                <Download className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            dir="auto"
            className="input flex-1 min-h-[200px] font-mono text-sm"
            placeholder={text ? "" : t.ocrNoText}
          />
        </div>
      </div>
    </div>
  );
}
