import { useState } from "react";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import fontkit from "@pdf-lib/fontkit";
import { useAppState } from "../store";
import { translations } from "../i18n";
import { DropZone, FilePreview } from "../components/DropZone";
import { toast } from "../components/Toast";
import { downloadBlob, readFileAsArrayBuffer, bytesToBlob } from "../utils";
import { addHistory } from "../store";
import { Loader2, Download, Plus, Trash2, FormInput, CheckSquare } from "lucide-react";
import { reshape } from "arabic-persian-reshaper";

const FONT_URL = "https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@33.003/fonts/webfonts/Vazirmatn-Regular.woff2";
let cached: ArrayBuffer | null = null;
async function getFont() {
  if (cached) return cached;
  const r = await fetch(FONT_URL);
  cached = await r.arrayBuffer();
  return cached;
}

interface FormField {
  id: string;
  type: "text" | "checkbox";
  label: string;
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
}

export function FormBuilder() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [file, setFile] = useState<File | null>(null);
  const [pageCount, setPageCount] = useState(1);
  const [fields, setFields] = useState<FormField[]>([]);
  const [label, setLabel] = useState("نام");
  const [fieldType, setFieldType] = useState<"text" | "checkbox">("text");
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const loadFile = async (f: File) => {
    setFile(f);
    try {
      const buf = await readFileAsArrayBuffer(f);
      const doc = await PDFDocument.load(buf, { ignoreEncryption: true });
      setPageCount(doc.getPageCount());
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
  };

  const addField = () => {
    if (!label) return;
    const newField: FormField = {
      id: Math.random().toString(36).slice(2),
      type: fieldType,
      label,
      page: currentPage,
      x: 50,
      y: 50,
      width: fieldType === "text" ? 200 : 20,
      height: fieldType === "text" ? 25 : 20,
    };
    setFields([...fields, newField]);
    setLabel("");
  };

  const remove = (id: string) => setFields(fields.filter(f => f.id !== id));

  const build = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const buf = await readFileAsArrayBuffer(file);
      const doc = await PDFDocument.load(buf, { ignoreEncryption: true });
      doc.registerFontkit(fontkit);
      const font = await doc.embedFont(await getFont(), { subset: true });
      const helv = await doc.embedFont(StandardFonts.Helvetica);

      const form = doc.getForm();
      for (const f of fields) {
        const page = doc.getPage(f.page - 1);
        const { height } = page.getSize();
        // PDF y axis from bottom
        const pdfY = height - f.y - f.height;
        if (f.type === "text") {
          const tf = form.createTextField(f.label);
          tf.addToPage(page, { x: f.x, y: pdfY, width: f.width, height: f.height, font: helv });
          // Add label
          const labelReshaped = /[\u0600-\u06FF]/.test(f.label) ? reshape(f.label) : f.label;
          page.drawText(labelReshaped, { x: f.x, y: pdfY + f.height + 5, size: 10, font, color: rgb(0.2, 0.2, 0.3) });
        } else {
          const cb = form.createCheckBox(f.label);
          cb.addToPage(page, { x: f.x, y: pdfY, width: f.width, height: f.height });
          page.drawText(f.label, { x: f.x + 30, y: pdfY + 5, size: 10, font, color: rgb(0.2, 0.2, 0.3) });
        }
      }

      const bytes = await doc.save();
      downloadBlob(bytesToBlob(bytes, "application/pdf"), "form.pdf");
      addHistory({ name: "form.pdf", tool: "form", size: bytes.byteLength });
      toast.show("success", t.downloaded);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  if (!file) return <DropZone accept="application/pdf" onFiles={(fs) => fs[0] && loadFile(fs[0])} hint={t.dragDrop} />;

  return (
    <div className="space-y-4">
      <FilePreview file={file} onRemove={() => { setFile(null); setFields([]); }} />

      <div className="glass-strong rounded-2xl p-4 space-y-3">
        <p className="text-sm font-semibold">{t.formAdd}</p>
        <div className="grid grid-cols-3 gap-2">
          <select value={fieldType} onChange={(e) => setFieldType(e.target.value as any)} className="input text-sm">
            <option value="text">{t.formText}</option>
            <option value="checkbox">{t.formCheckbox}</option>
          </select>
          <input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Label" className="input text-sm col-span-2" />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm">Page:</span>
          <select value={currentPage} onChange={(e) => setCurrentPage(+e.target.value)} className="input text-sm flex-1">
            {Array.from({ length: pageCount }, (_, i) => i + 1).map(n => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
          <button onClick={addField} className="btn-primary text-sm flex items-center gap-1">
            <Plus className="h-4 w-4" />{t.formAdd}
          </button>
        </div>
      </div>

      {fields.length > 0 && (
        <div className="glass-strong rounded-2xl p-4 space-y-2">
          <p className="text-sm font-semibold">{fields.length} {t.formField}</p>
          {fields.map(f => (
            <div key={f.id} className="flex items-center gap-2 p-2 rounded-lg hover:bg-violet-50 dark:hover:bg-violet-900/20">
              {f.type === "text" ? <FormInput className="h-4 w-4 text-violet-500" /> : <CheckSquare className="h-4 w-4 text-pink-500" />}
              <span className="flex-1 text-sm">{f.label} <span className="text-xs text-slate-500">(page {f.page})</span></span>
              <button onClick={() => remove(f.id)} className="p-1.5 rounded text-red-500 hover:bg-red-50 dark:hover:bg-red-950"><Trash2 className="h-3.5 w-3.5" /></button>
            </div>
          ))}
        </div>
      )}

      <button onClick={build} disabled={loading || fields.length === 0} className="btn-primary w-full flex items-center justify-center gap-2">
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
        {t.process} & {t.download}
      </button>
    </div>
  );
}
