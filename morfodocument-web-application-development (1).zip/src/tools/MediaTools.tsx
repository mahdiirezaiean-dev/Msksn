import { useState, useEffect } from "react";
import { PDFDocument } from "pdf-lib";
import imageCompression from "browser-image-compression";
import { useAppState } from "../store";
import { translations } from "../i18n";
import { DropZone, FilePreview } from "../components/DropZone";
import { toast } from "../components/Toast";
import { downloadBlob, bytesToBlob, formatBytes } from "../utils";
import { addHistory } from "../store";
import { Loader2, Download, Trash2, ArrowUp, ArrowDown } from "lucide-react";

// ============ COMPRESS IMAGE ============
export function CompressImage() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [file, setFile] = useState<File | null>(null);
  const [quality, setQuality] = useState(0.7);
  const [maxWidth, setMaxWidth] = useState(1920);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ blob: Blob; size: number } | null>(null);
  const [originalSize, setOriginalSize] = useState(0);
  const [previewOriginal, setPreviewOriginal] = useState<string | null>(null);
  const [previewCompressed, setPreviewCompressed] = useState<string | null>(null);

  useEffect(() => {
    if (file) {
      setOriginalSize(file.size);
      const url = URL.createObjectURL(file);
      setPreviewOriginal(url);
      return () => URL.revokeObjectURL(url);
    }
  }, [file]);

  const process = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const compressed = await imageCompression(file, {
        maxSizeMB: quality * 5,
        maxWidthOrHeight: maxWidth,
        initialQuality: quality,
        useWebWorker: true,
      });
      setResult({ blob: compressed, size: compressed.size });
      setPreviewCompressed(URL.createObjectURL(compressed));
      addHistory({ name: file.name, tool: "compress-image", size: compressed.size });
      toast.show("success", t.downloaded);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  if (!file) return <DropZone accept="image/*" onFiles={(fs) => fs[0] && setFile(fs[0])} hint={t.dragDrop + " — Image"} />;

  const saved = result ? originalSize - result.size : 0;
  const savedPct = result ? Math.round((saved / originalSize) * 100) : 0;

  return (
    <div className="space-y-4">
      <FilePreview file={file} onRemove={() => { setFile(null); setResult(null); setPreviewCompressed(null); }} />
      <div className="glass-strong rounded-2xl p-4 space-y-3">
        <label className="block">
          <span className="text-sm font-medium">{t.compressQuality}: {Math.round(quality * 100)}%</span>
          <input type="range" min="0.1" max="1" step="0.05" value={quality} onChange={(e) => setQuality(+e.target.value)} className="mt-1" />
        </label>
        <label className="block">
          <span className="text-sm font-medium">{t.size}: {maxWidth}px</span>
          <input type="range" min="320" max="4096" step="64" value={maxWidth} onChange={(e) => setMaxWidth(+e.target.value)} className="mt-1" />
        </label>
      </div>
      {previewOriginal && previewCompressed && (
        <div className="grid grid-cols-2 gap-3">
          <div className="glass rounded-2xl p-3">
            <p className="text-xs mb-1">{t.originalSize}: {formatBytes(originalSize)}</p>
            <img src={previewOriginal} className="w-full rounded-lg" alt="Original" />
          </div>
          <div className="glass rounded-2xl p-3">
            <p className="text-xs mb-1">{t.newSize}: {formatBytes(result?.size || 0)}</p>
            <img src={previewCompressed} className="w-full rounded-lg" alt="Compressed" />
          </div>
        </div>
      )}
      {result && (
        <div className="glass rounded-2xl p-3 text-center">
          <p className="text-sm text-emerald-600 font-semibold">🎉 {t.saved}: {formatBytes(saved)} ({savedPct}%)</p>
        </div>
      )}
      <div className="flex gap-2">
        <button onClick={process} disabled={loading} className="btn-primary flex-1 flex items-center justify-center gap-2">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Loader2 className="h-4 w-4" />}
          {t.process}
        </button>
        {result && (
          <button onClick={() => downloadBlob(result.blob, `compressed_${file.name}`)} className="btn-primary flex-1 flex items-center justify-center gap-2">
            <Download className="h-4 w-4" />{t.download}
          </button>
        )}
      </div>
    </div>
  );
}

// ============ COMPRESS PDF ============
export function CompressPdf() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ size: number } | null>(null);
  const [originalSize, setOriginalSize] = useState(0);
  const [progress, setProgress] = useState(0);

  const process = async () => {
    if (!file) return;
    setLoading(true);
    setProgress(0);
    try {
      const pdfjs: any = await import("pdfjs-dist");
      const buf = await file.arrayBuffer();
      const doc = await pdfjs.getDocument({ data: buf.slice(0) }).promise;
      const out = await PDFDocument.create();
      const total = doc.numPages;

      for (let i = 1; i <= total; i++) {
        const page = await doc.getPage(i);
        const viewport = page.getViewport({ scale: 1.5 });
        const canvas = document.createElement("canvas");
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const ctx = canvas.getContext("2d")!;
        await page.render({ canvas, canvasContext: ctx, viewport } as any).promise;
        const blob: Blob = await new Promise(res => canvas.toBlob(b => res(b!), "image/jpeg", 0.75)!);
        const bytes = new Uint8Array(await blob.arrayBuffer());
        const jpg = await out.embedJpg(bytes);
        const newPage = out.addPage([viewport.width, viewport.height]);
        newPage.drawImage(jpg, { x: 0, y: 0, width: viewport.width, height: viewport.height });
        setProgress(Math.round((i / total) * 100));
      }

      const finalBytes = await out.save();
      const size = finalBytes.byteLength;
      setResult({ size });
      setOriginalSize(file.size);
      downloadBlob(bytesToBlob(finalBytes, "application/pdf"), "compressed.pdf");
      addHistory({ name: "compressed.pdf", tool: "compress-pdf", size });
      toast.show("success", t.downloaded);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  if (!file) return <DropZone accept="application/pdf" onFiles={(fs) => fs[0] && setFile(fs[0])} hint={t.dragDrop} />;

  const saved = result ? originalSize - result.size : 0;
  const savedPct = result ? Math.max(0, Math.round((saved / originalSize) * 100)) : 0;

  return (
    <div className="space-y-4">
      <FilePreview file={file} onRemove={() => { setFile(null); setResult(null); }} />
      {loading && (
        <div className="glass-strong rounded-2xl p-4">
          <div className="h-2 bg-violet-100 dark:bg-violet-900/30 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-violet-500 to-pink-500 transition-all" style={{ width: `${progress}%` }} />
          </div>
          <p className="text-center text-sm mt-2">{progress}%</p>
        </div>
      )}
      {result && (
        <div className="glass rounded-2xl p-4 space-y-1 text-center">
          <p>{t.originalSize}: <b>{formatBytes(originalSize)}</b></p>
          <p>{t.newSize}: <b>{formatBytes(result.size)}</b></p>
          {saved > 0 && <p className="text-emerald-600 font-semibold">{t.saved}: {formatBytes(saved)} ({savedPct}%)</p>}
        </div>
      )}
      <button onClick={process} disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
        {t.process} & {t.download}
      </button>
    </div>
  );
}

// ============ PDF TO IMAGES ============
export function PdfToImages() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [file, setFile] = useState<File | null>(null);
  const [format, setFormat] = useState<"png" | "jpeg" | "webp">("jpeg");
  const [quality, setQuality] = useState(0.9);
  const [scale, setScale] = useState(2);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [images, setImages] = useState<{ name: string; blob: Blob }[]>([]);

  const process = async () => {
    if (!file) return;
    setLoading(true);
    setProgress(0);
    try {
      const pdfjs: any = await import("pdfjs-dist");
      const buf = await file.arrayBuffer();
      const doc = await pdfjs.getDocument({ data: buf.slice(0) }).promise;
      const imgs: { name: string; blob: Blob }[] = [];
      for (let i = 1; i <= doc.numPages; i++) {
        const page = await doc.getPage(i);
        const viewport = page.getViewport({ scale });
        const canvas = document.createElement("canvas");
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const ctx = canvas.getContext("2d")!;
        await page.render({ canvas, canvasContext: ctx, viewport } as any).promise;
        const mime = format === "png" ? "image/png" : format === "webp" ? "image/webp" : "image/jpeg";
        const blob: Blob = await new Promise(res => canvas.toBlob(b => res(b!), mime, quality)!);
        const baseName = file.name.replace(/\.pdf$/i, "");
        imgs.push({ name: `${baseName}_page_${i}.${format}`, blob });
        setProgress(Math.round((i / doc.numPages) * 100));
      }
      setImages(imgs);
      addHistory({ name: file.name, tool: "pdf2image", size: imgs.reduce((s, i) => s + i.blob.size, 0) });
      toast.show("success", t.success);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  if (!file) return <DropZone accept="application/pdf" onFiles={(fs) => fs[0] && setFile(fs[0])} hint={t.dragDrop} />;

  return (
    <div className="space-y-4">
      <FilePreview file={file} onRemove={() => { setFile(null); setImages([]); }} />
      <div className="glass-strong rounded-2xl p-4 grid grid-cols-3 gap-2 sm:gap-3">
        <label className="block">
          <span className="text-xs font-medium">Format</span>
          <select value={format} onChange={(e) => setFormat(e.target.value as any)} className="input mt-1 !py-2 text-sm">
            <option value="jpeg">JPG</option>
            <option value="png">PNG</option>
            <option value="webp">WebP</option>
          </select>
        </label>
        <label className="block">
          <span className="text-xs font-medium">{t.compressQuality}: {Math.round(quality * 100)}%</span>
          <input type="range" min="0.1" max="1" step="0.05" value={quality} onChange={(e) => setQuality(+e.target.value)} className="mt-1" />
        </label>
        <label className="block">
          <span className="text-xs font-medium">Scale: {scale}x</span>
          <input type="range" min="1" max="4" step="0.5" value={scale} onChange={(e) => setScale(+e.target.value)} className="mt-1" />
        </label>
      </div>
      {loading && (
        <div className="glass-strong rounded-2xl p-4">
          <div className="h-2 bg-violet-100 dark:bg-violet-900/30 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-violet-500 to-pink-500 transition-all" style={{ width: `${progress}%` }} />
          </div>
          <p className="text-center text-sm mt-2">{progress}%</p>
        </div>
      )}
      <button onClick={process} disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
        {t.process}
      </button>
      {images.length > 0 && (
        <div className="glass-strong rounded-2xl p-4 space-y-2">
          <p className="font-semibold text-sm">{images.length} {t.pageCount}</p>
          {images.map((img, i) => (
            <button
              key={i}
              onClick={() => downloadBlob(img.blob, img.name)}
              className="w-full text-start p-3 rounded-xl hover:bg-violet-100 dark:hover:bg-violet-900/30 flex items-center gap-2 text-sm"
            >
              <Download className="h-4 w-4 text-violet-500" />
              <span className="flex-1 truncate">{img.name}</span>
              <span className="text-xs text-slate-500">{formatBytes(img.blob.size)}</span>
            </button>
          ))}
          <button onClick={() => {
            images.forEach((img, i) => setTimeout(() => downloadBlob(img.blob, img.name), i * 200));
          }} className="btn-primary w-full text-sm">
            {t.download} {t.fileSelected}
          </button>
        </div>
      )}
    </div>
  );
}

// ============ IMAGES TO PDF ============
export function ImagesToPdf() {
  const { locale } = useAppState();
  const t = translations[locale];
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [pageSize, setPageSize] = useState<"a4" | "letter" | "fit">("a4");

  useEffect(() => {
    previews.forEach(p => URL.revokeObjectURL(p));
    setPreviews(files.map(f => URL.createObjectURL(f)));
  }, [files]);

  const move = (idx: number, dir: -1 | 1) => {
    const arr = [...files];
    const t2 = idx + dir;
    if (t2 < 0 || t2 >= arr.length) return;
    [arr[idx], arr[t2]] = [arr[t2], arr[idx]];
    setFiles(arr);
  };

  const remove = (idx: number) => setFiles(files.filter((_, i) => i !== idx));

  const process = async () => {
    if (files.length === 0) return;
    setLoading(true);
    try {
      const pdf = await PDFDocument.create();
      for (const file of files) {
        const buf = await file.arrayBuffer();
        let img;
        if (file.type === "image/png") img = await pdf.embedPng(buf);
        else img = await pdf.embedJpg(buf);
        const imgDims = img.scale(1);
        let pageW, pageH;
        if (pageSize === "a4") { pageW = 595.28; pageH = 841.89; }
        else if (pageSize === "letter") { pageW = 612; pageH = 792; }
        else { pageW = imgDims.width; pageH = imgDims.height; }

        const page = pdf.addPage([pageW, pageH]);
        const ratio = Math.min(pageW / imgDims.width, pageH / imgDims.height);
        const w = imgDims.width * ratio * 0.95;
        const h = imgDims.height * ratio * 0.95;
        page.drawImage(img, { x: (pageW - w) / 2, y: (pageH - h) / 2, width: w, height: h });
      }
      const bytes = await pdf.save();
      downloadBlob(bytesToBlob(bytes, "application/pdf"), "images.pdf");
      addHistory({ name: "images.pdf", tool: "image2pdf", size: bytes.byteLength });
      toast.show("success", t.downloaded);
    } catch (e: any) {
      toast.show("error", e?.message || t.error);
    }
    setLoading(false);
  };

  return (
    <div className="space-y-4">
      <DropZone accept="image/*" multiple onFiles={(fs) => setFiles([...files, ...fs])} hint={t.dragDrop} />
      {files.length > 0 && (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {files.map((_f, i) => (
              <div key={i} className="glass rounded-2xl p-2 relative group">
                {previews[i] && <img src={previews[i]} className="w-full aspect-square object-cover rounded-lg" alt="" />}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl flex items-center justify-center gap-1">
                  <button onClick={() => move(i, -1)} className="p-1.5 rounded bg-white/80"><ArrowUp className="h-3 w-3" /></button>
                  <button onClick={() => move(i, 1)} className="p-1.5 rounded bg-white/80"><ArrowDown className="h-3 w-3" /></button>
                  <button onClick={() => remove(i)} className="p-1.5 rounded bg-red-500 text-white"><Trash2 className="h-3 w-3" /></button>
                </div>
                <span className="absolute top-2 start-2 bg-black/60 text-white text-xs px-2 py-0.5 rounded">{i + 1}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-2 flex-wrap">
            <select value={pageSize} onChange={(e) => setPageSize(e.target.value as any)} className="input flex-1 min-w-[120px]">
              <option value="a4">A4</option>
              <option value="letter">Letter</option>
              <option value="fit">Fit Image</option>
            </select>
            <button onClick={process} disabled={loading} className="btn-primary flex-1 min-w-[150px] flex items-center justify-center gap-2">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
              {t.process} ({files.length})
            </button>
          </div>
        </>
      )}
    </div>
  );
}
