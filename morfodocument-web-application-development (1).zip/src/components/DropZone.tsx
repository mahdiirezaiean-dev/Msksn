import { useState, useRef, DragEvent, ChangeEvent } from "react";
import { Upload, FileText, Image as ImageIcon } from "lucide-react";
import { cn } from "../utils";

interface Props {
  accept?: string;
  multiple?: boolean;
  onFiles: (files: File[]) => void;
  hint?: string;
  icon?: React.ReactNode;
  className?: string;
}

export function DropZone({ accept = "*/*", multiple = false, onFiles, hint, icon, className }: Props) {
  const [drag, setDrag] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handle = (files: FileList | null) => {
    if (!files) return;
    const arr = Array.from(files);
    onFiles(arr);
  };

  const onDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDrag(false);
    handle(e.dataTransfer.files);
  };

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
      onDragLeave={() => setDrag(false)}
      onDrop={onDrop}
      onClick={() => inputRef.current?.click()}
      className={cn(
        "glass-strong rounded-3xl p-8 sm:p-12 border-2 border-dashed cursor-pointer transition-all duration-300 text-center group",
        drag ? "drag-over border-violet-500 scale-[1.02]" : "border-violet-200 dark:border-violet-800 hover:border-violet-400",
        className
      )}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        onChange={(e: ChangeEvent<HTMLInputElement>) => handle(e.target.files)}
        className="hidden"
      />
      <div className="flex flex-col items-center gap-4">
        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-pink-500 flex items-center justify-center shadow-lg shadow-violet-300 dark:shadow-violet-900 group-hover:scale-110 transition-transform duration-300">
          {icon || <Upload className="h-8 w-8 sm:h-10 sm:w-10 text-white" />}
        </div>
        <div>
          <p className="text-base sm:text-lg font-semibold text-violet-900 dark:text-violet-100">
            {hint || "فایل را اینجا رها کنید"}
          </p>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            یا کلیک کنید برای انتخاب
          </p>
        </div>
      </div>
    </div>
  );
}

interface FilePreviewProps {
  file: File;
  onRemove?: () => void;
  size?: number;
}

export function FilePreview({ file, onRemove, size }: FilePreviewProps) {
  const isImage = file.type.startsWith("image/");
  const Icon = isImage ? ImageIcon : FileText;

  return (
    <div className="glass rounded-2xl p-4 flex items-center gap-3">
      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center flex-shrink-0">
        <Icon className="h-6 w-6 text-white" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-medium truncate">{file.name}</p>
        <p className="text-xs text-slate-500 dark:text-slate-400">{size !== undefined ? formatSize(size) : formatSize(file.size)}</p>
      </div>
      {onRemove && (
        <button onClick={onRemove} className="text-red-500 hover:bg-red-50 dark:hover:bg-red-950 rounded-lg p-2 transition-colors">
          ×
        </button>
      )}
    </div>
  );
}

function formatSize(b: number): string {
  if (b < 1024) return b + " B";
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + " KB";
  return (b / 1024 / 1024).toFixed(2) + " MB";
}
