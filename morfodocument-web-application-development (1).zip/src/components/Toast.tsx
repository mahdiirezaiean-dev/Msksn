import { useEffect, useState } from "react";
import { CheckCircle, XCircle, Info, AlertCircle, X } from "lucide-react";

export type ToastType = "success" | "error" | "info" | "warning";
export interface ToastItem {
  id: string;
  type: ToastType;
  message: string;
}

class ToastManager {
  private listeners = new Set<(t: ToastItem[]) => void>();
  private toasts: ToastItem[] = [];

  subscribe(l: (t: ToastItem[]) => void) {
    this.listeners.add(l);
    l(this.toasts);
    return () => { this.listeners.delete(l); };
  }

  private set(next: ToastItem[]) {
    this.toasts = next;
    this.listeners.forEach(l => l(this.toasts));
  }

  show(type: ToastType, message: string, duration = 4000) {
    const id = Math.random().toString(36).slice(2);
    this.set([...this.toasts, { id, type, message }]);
    setTimeout(() => {
      this.set(this.toasts.filter(t => t.id !== id));
    }, duration);
  }
}

export const toast = new ToastManager();

export function ToastContainer() {
  const [items, setItems] = useState<ToastItem[]>([]);
  useEffect(() => toast.subscribe(setItems), []);

  const icons = {
    success: <CheckCircle className="h-5 w-5 text-emerald-500" />,
    error: <XCircle className="h-5 w-5 text-red-500" />,
    info: <Info className="h-5 w-5 text-blue-500" />,
    warning: <AlertCircle className="h-5 w-5 text-amber-500" />,
  };

  return (
    <div className="fixed top-4 right-4 z-[9999] flex flex-col gap-2 max-w-sm">
      {items.map(t => (
        <div key={t.id} className="toast-anim glass-strong rounded-2xl px-4 py-3 flex items-center gap-3 min-w-[280px]">
          {icons[t.type]}
          <span className="flex-1 text-sm">{t.message}</span>
          <button onClick={() => setItems(items.filter(i => i.id !== t.id))} className="opacity-50 hover:opacity-100">
            <X className="h-4 w-4" />
          </button>
        </div>
      ))}
    </div>
  );
}
