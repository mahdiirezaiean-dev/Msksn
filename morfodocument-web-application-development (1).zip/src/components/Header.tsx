import { useState, useEffect, useRef } from "react";
import { Moon, Sun, Globe, Menu, X, ChevronDown } from "lucide-react";
import { useAppState, setTheme, setLocale, Locale } from "../store";
import { translations, localeInfo } from "../i18n";
import { cn } from "../utils";

interface Props {
  onNavigate: (page: string) => void;
  current: string;
}

export function Header({ onNavigate, current }: Props) {
  const { theme, locale } = useAppState();
  const t = translations[locale];
  const [langOpen, setLangOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(e.target as Node)) setLangOpen(false);
    };
    document.addEventListener("click", handler);
    return () => document.removeEventListener("click", handler);
  }, []);

  const navItems = [
    { id: "home", label: t.home },
    { id: "about", label: t.about },
    { id: "contact", label: t.contact },
  ];

  return (
    <header className="sticky top-0 z-50 glass-strong border-b border-white/30 dark:border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between gap-4">
        <button onClick={() => onNavigate("home")} className="flex items-center gap-2 sm:gap-3 group">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-pink-500 flex items-center justify-center shadow-lg shadow-violet-300 dark:shadow-violet-900 group-hover:scale-110 transition-transform">
            <span className="text-white font-black text-lg sm:text-xl">M</span>
          </div>
          <div className="hidden sm:block">
            <div className="font-black text-lg bg-gradient-to-r from-violet-600 to-pink-600 bg-clip-text text-transparent leading-tight">MorfoDocument</div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400 leading-tight">{t.tagline}</div>
          </div>
        </button>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map(n => (
            <button
              key={n.id}
              onClick={() => onNavigate(n.id)}
              className={cn(
                "px-4 py-2 rounded-xl text-sm font-medium transition-all",
                current === n.id
                  ? "bg-gradient-to-r from-violet-500 to-pink-500 text-white shadow-md"
                  : "text-slate-700 dark:text-slate-300 hover:bg-violet-100 dark:hover:bg-violet-900/30"
              )}
            >
              {n.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          {/* Language switcher */}
          <div ref={langRef} className="relative">
            <button
              onClick={() => setLangOpen(!langOpen)}
              className="btn-secondary !py-2 !px-3 flex items-center gap-1.5 text-sm"
            >
              <Globe className="h-4 w-4" />
              <span className="hidden sm:inline">{localeInfo[locale].native}</span>
              <span className="sm:hidden">{localeInfo[locale].flag}</span>
              <ChevronDown className="h-3 w-3" />
            </button>
            {langOpen && (
              <div className="absolute top-full mt-2 end-0 glass-strong rounded-2xl p-2 min-w-[180px] shadow-2xl border border-white/40 dark:border-white/10 max-h-80 overflow-y-auto">
                {Object.entries(localeInfo).map(([code, info]) => (
                  <button
                    key={code}
                    onClick={() => { setLocale(code as Locale); setLangOpen(false); }}
                    className={cn(
                      "w-full text-start px-3 py-2 rounded-xl text-sm flex items-center gap-2 transition-colors",
                      locale === code
                        ? "bg-gradient-to-r from-violet-500 to-pink-500 text-white"
                        : "hover:bg-violet-100 dark:hover:bg-violet-900/30"
                    )}
                  >
                    <span>{info.flag}</span>
                    <span className="flex-1">{info.native}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Theme toggle */}
          <button
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
            className="btn-secondary !py-2 !px-3"
            aria-label="Toggle theme"
          >
            {theme === "light" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          </button>

          {/* Mobile menu */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden btn-secondary !py-2 !px-3"
            aria-label="Menu"
          >
            {mobileOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Mobile nav */}
      {mobileOpen && (
        <div className="md:hidden border-t border-white/30 dark:border-white/5 bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl">
          <div className="px-4 py-3 space-y-1">
            {navItems.map(n => (
              <button
                key={n.id}
                onClick={() => { onNavigate(n.id); setMobileOpen(false); }}
                className={cn(
                  "w-full text-start px-4 py-3 rounded-xl text-sm font-medium transition-all",
                  current === n.id
                    ? "bg-gradient-to-r from-violet-500 to-pink-500 text-white"
                    : "text-slate-700 dark:text-slate-300 hover:bg-violet-100 dark:hover:bg-violet-900/30"
                )}
              >
                {n.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
