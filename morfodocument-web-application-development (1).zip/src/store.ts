import { useState, useEffect } from "react";

export type Locale = "fa" | "en" | "ar" | "es" | "fr" | "zh" | "hi" | "pt" | "ru" | "de";
export type Theme = "light" | "dark";

const STORAGE_KEY = "morfo-state-v1";
const HISTORY_KEY = "morfo-history-v1";

export interface AppState {
  locale: Locale;
  theme: Theme;
}

function loadState(): AppState {
  if (typeof window === "undefined") return { locale: "fa", theme: "light" };
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const s = JSON.parse(raw);
      return { locale: s.locale || "fa", theme: s.theme || "light" };
    }
  } catch {}
  return { locale: "fa", theme: "light" };
}

let state: AppState = loadState();
const listeners = new Set<() => void>();

function notify() {
  listeners.forEach((l) => l());
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {}
}

export function getState(): AppState { return state; }

export function setLocale(l: Locale) {
  state = { ...state, locale: l };
  if (typeof document !== "undefined") {
    document.documentElement.lang = l;
    document.documentElement.dir = l === "fa" || l === "ar" ? "rtl" : "ltr";
  }
  notify();
}

export function setTheme(t: Theme) {
  state = { ...state, theme: t };
  if (typeof document !== "undefined") {
    document.documentElement.classList.toggle("dark", t === "dark");
  }
  notify();
}

export function useAppState(): AppState {
  const [, setTick] = useState(0);
  useEffect(() => {
    const l = () => setTick((x) => x + 1);
    listeners.add(l);
    return () => { listeners.delete(l); };
  }, []);
  return state;
}

// Initialize DOM
if (typeof document !== "undefined") {
  document.documentElement.lang = state.locale;
  document.documentElement.dir = state.locale === "fa" || state.locale === "ar" ? "rtl" : "ltr";
  document.documentElement.classList.toggle("dark", state.theme === "dark");
}

// History (simple localStorage)
export interface HistoryItem {
  id: string;
  name: string;
  tool: string;
  timestamp: number;
  size: number;
}

export function getHistory(): HistoryItem[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}

export function addHistory(item: Omit<HistoryItem, "id" | "timestamp">) {
  const list = getHistory();
  const newItem: HistoryItem = { ...item, id: Math.random().toString(36).slice(2), timestamp: Date.now() };
  list.unshift(newItem);
  if (list.length > 30) list.pop();
  try { localStorage.setItem(HISTORY_KEY, JSON.stringify(list)); } catch {}
  if (typeof window !== "undefined") window.dispatchEvent(new Event("morfo-history-updated"));
}

export function clearHistory() {
  try { localStorage.removeItem(HISTORY_KEY); } catch {}
  if (typeof window !== "undefined") window.dispatchEvent(new Event("morfo-history-updated"));
}
